package com.qi.petlife

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class PetCanvasView(context: Context) : View(context), Drawable.Callback {
    var slot: PetSlot = PetSlot()
        set(value) {
            val uriChanged = field.customUri != value.customUri || field.petId != value.petId
            field = value
            alpha = value.opacity / 100f
            setLayerType(if (value.shadow) LAYER_TYPE_SOFTWARE else LAYER_TYPE_HARDWARE, null)
            if (uriChanged) loadCustomDrawable()
            invalidate()
        }
    var forcedExpression: Int? = null
    var action: String = "idle"
    var facingRight: Boolean = true
    var animationEnabled: Boolean = true

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val path = Path()
    private var customDrawable: Drawable? = null
    private var customBitmap: Bitmap? = null
    private var trimRect: Rect? = null
    private var loadedUri = ""
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1600L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { if (animationEnabled) invalidate() }
    }

    init {
        isClickable = true
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isStarted) animator.start()
        if (Build.VERSION.SDK_INT >= 28) (customDrawable as? AnimatedImageDrawable)?.start()
    }

    override fun onDetachedFromWindow() {
        if (Build.VERSION.SDK_INT >= 28) (customDrawable as? AnimatedImageDrawable)?.stop()
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun verifyDrawable(who: Drawable): Boolean = who === customDrawable || super.verifyDrawable(who)
    override fun invalidateDrawable(who: Drawable) {
        invalidate()
    }

    private fun loadCustomDrawable() {
        customDrawable = null
        customBitmap = null
        trimRect = null
        loadedUri = slot.customUri
        if (slot.petId != "custom" || loadedUri.isBlank()) return
        runCatching {
            val uri = Uri.parse(loadedUri)
            if (Build.VERSION.SDK_INT >= 28) {
                val source = ImageDecoder.createSource(context.contentResolver, uri)
                val drawable = ImageDecoder.decodeDrawable(source) { decoder, _, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    decoder.isMutableRequired = false
                }
                if (drawable is AnimatedImageDrawable) {
                    drawable.callback = this
                    customDrawable = drawable
                    drawable.start()
                } else if (drawable is BitmapDrawable) {
                    customBitmap = drawable.bitmap
                    trimRect = alphaBounds(drawable.bitmap)
                } else {
                    drawable.callback = this
                    customDrawable = drawable
                }
            } else {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    customBitmap = BitmapFactory.decodeStream(stream)
                    trimRect = customBitmap?.let { alphaBounds(it) }
                }
            }
        }
    }

    private fun alphaBounds(bitmap: Bitmap): Rect {
        val w = bitmap.width
        val h = bitmap.height
        if (!bitmap.hasAlpha() || w * h > 12_000_000) return Rect(0, 0, w, h)
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        var left = w; var right = -1; var top = h; var bottom = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if ((pixels[row + x] ushr 24) > 8) {
                    if (x < left) left = x
                    if (x > right) right = x
                    if (y < top) top = y
                    if (y > bottom) bottom = y
                }
            }
        }
        return if (right < left || bottom < top) Rect(0, 0, w, h) else Rect(left, top, right + 1, bottom + 1)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (slot.petId == "custom" && (customDrawable != null || customBitmap != null)) {
            drawCustom(canvas)
            return
        }
        val definition = PetCatalog.get(slot.petId)
        val p = if (slot.useCustomColors) slot.primaryColor else definition.primary
        val s = if (slot.useCustomColors) slot.secondaryColor else definition.secondary
        val a = if (slot.useCustomColors) slot.accentColor else definition.accent
        val scale = min(width, height) / 228f
        val t = SystemClock.elapsedRealtime() / 1000f
        val breathe = if (animationEnabled) 1f + sin(t * 2.25f) * 0.018f else 1f
        val bounce = when (action) {
            "jump" -> -kotlin.math.abs(sin(t * 6f)) * 22f
            "happy" -> -kotlin.math.abs(sin(t * 8f)) * 8f
            "sleep" -> 7f
            else -> if (animationEnabled) sin(t * 2.25f) * 2.2f else 0f
        }
        canvas.save()
        canvas.translate(width / 2f, height / 2f + bounce * scale)
        canvas.scale(scale * breathe * if (facingRight xor slot.mirror) 1f else -1f, scale * breathe)
        canvas.translate(-110f, -110f)

        when (definition.family) {
            PetFamily.CAT -> drawCat(canvas, definition, p, s, a, t)
            PetFamily.DOG, PetFamily.WOLF, PetFamily.FOX -> drawCanine(canvas, definition, p, s, a, t)
            PetFamily.RABBIT -> drawRabbit(canvas, definition, p, s, a, t)
            PetFamily.BEAR -> drawBear(canvas, definition, p, s, a, t)
            PetFamily.RODENT, PetFamily.OTTER -> drawRodent(canvas, definition, p, s, a, t)
            PetFamily.DEER, PetFamily.SHEEP, PetFamily.ALPACA, PetFamily.UNICORN -> drawHoof(canvas, definition, p, s, a, t)
            PetFamily.BIRD, PetFamily.CHICK, PetFamily.OWL, PetFamily.PENGUIN -> drawBird(canvas, definition, p, s, a, t)
            PetFamily.FROG, PetFamily.TURTLE -> drawPond(canvas, definition, p, s, a, t)
            PetFamily.SEAL, PetFamily.WHALE, PetFamily.OCTOPUS -> drawOcean(canvas, definition, p, s, a, t)
            PetFamily.DINO, PetFamily.DRAGON -> drawDino(canvas, definition, p, s, a, t)
            PetFamily.SLIME, PetFamily.GHOST, PetFamily.SPIRIT, PetFamily.CLOUD, PetFamily.STAR -> drawFantasy(canvas, definition, p, s, a, t)
            PetFamily.ROBOT, PetFamily.ALIEN -> drawRobot(canvas, definition, p, s, a, t)
        }
        drawAccessory(canvas, definition.accessory, p, s, a, t)
        canvas.restore()
    }

    private fun drawCustom(canvas: Canvas) {
        val padding = min(width, height) * .035f
        val dst = RectF(padding, padding, width - padding, height - padding)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            // View.alpha already applies the configured opacity. Keep bitmap alpha at full strength
            // so custom images do not become accidentally double-transparent.
            alpha = 255
            if (slot.useCustomColors) colorFilter = PorterDuffColorFilter(slot.primaryColor, PorterDuff.Mode.SRC_ATOP)
            if (slot.shadow) setShadowLayer(min(width, height) * .035f, 0f, min(width, height) * .018f, 0x66000000)
        }
        canvas.save()
        if (slot.mirror) canvas.scale(-1f, 1f, width / 2f, height / 2f)
        customBitmap?.let { bitmap -> canvas.drawBitmap(bitmap, trimRect ?: Rect(0, 0, bitmap.width, bitmap.height), dst, paint) }
        customDrawable?.let { drawable ->
            drawable.alpha = paint.alpha
            drawable.colorFilter = paint.colorFilter
            drawable.bounds = Rect(dst.left.toInt(), dst.top.toInt(), dst.right.toInt(), dst.bottom.toInt())
            drawable.draw(canvas)
        }
        canvas.restore()
    }

    private fun bodyPaint(color: Int, shadow: Boolean = slot.shadow): Paint = fill.apply {
        style = Paint.Style.FILL
        shader = LinearGradient(0f, 30f, 0f, 205f, lighten(color, 1.14f), darken(color, .90f), Shader.TileMode.CLAMP)
        this.color = color
        if (shadow) setShadowLayer(8f, 0f, 5f, 0x55000000) else clearShadowLayer()
    }

    private fun flat(color: Int): Paint = fill.apply { style = Paint.Style.FILL; shader = null; this.color = color; clearShadowLayer() }

    private fun outline(canvas: Canvas, shape: () -> Unit) {
        if (!slot.outline) return
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = 3.4f
        stroke.color = 0x55352F43
        stroke.shader = null
        shape()
    }

    private fun drawCat(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        val tail = sin(t * 2.6f + d.variant) * 12f
        stroke.strokeWidth = 17f; stroke.color = p; stroke.shader = null
        c.drawArc(RectF(145f + tail, 113f, 210f + tail, 184f), -95f, 215f, false, stroke)
        c.drawOval(RectF(48f, 99f, 171f, 202f), bodyPaint(p))
        val foot = if (action == "walk") sin(t * 10f) * 6f else 0f
        c.drawOval(RectF(59f, 174f + foot, 101f, 210f), bodyPaint(p))
        c.drawOval(RectF(118f, 174f - foot, 160f, 210f), bodyPaint(p))
        path.reset(); path.moveTo(52f, 83f); path.lineTo(43f, 27f); path.lineTo(91f, 60f); path.close(); c.drawPath(path, bodyPaint(p))
        path.reset(); path.moveTo(128f, 60f); path.lineTo(177f, 27f); path.lineTo(168f, 84f); path.close(); c.drawPath(path, bodyPaint(p))
        path.reset(); path.moveTo(55f, 68f); path.lineTo(50f, 42f); path.lineTo(76f, 61f); path.close(); c.drawPath(path, flat(a))
        path.reset(); path.moveTo(145f, 61f); path.lineTo(170f, 42f); path.lineTo(162f, 70f); path.close(); c.drawPath(path, flat(a))
        c.drawOval(RectF(43f, 48f, 177f, 155f), bodyPaint(p))
        drawMarkings(c, d.variant, p, s, a)
        drawFace(c, 110f, 101f, s, a, t)
        drawWhiskers(c, s)
    }

    private fun drawCanine(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        val fox = d.family == PetFamily.FOX
        val wolf = d.family == PetFamily.WOLF
        val tail = sin(t * 3.1f) * 10f
        if (fox) {
            c.drawOval(RectF(134f + tail, 118f, 214f + tail, 196f), bodyPaint(p))
            c.drawOval(RectF(177f + tail, 157f, 215f + tail, 197f), bodyPaint(lighten(p, 1.38f)))
        } else {
            stroke.strokeWidth = 16f; stroke.color = p
            c.drawArc(RectF(146f + tail, 116f, 207f + tail, 176f), -75f, 180f, false, stroke)
        }
        c.drawOval(RectF(48f, 100f, 172f, 203f), bodyPaint(p))
        c.drawOval(RectF(58f, 176f, 101f, 210f), bodyPaint(if (wolf) s else p))
        c.drawOval(RectF(119f, 176f, 162f, 210f), bodyPaint(if (wolf) s else p))
        if (fox || wolf) {
            path.reset(); path.moveTo(46f, 83f); path.lineTo(44f, 27f); path.lineTo(90f, 61f); path.close(); c.drawPath(path, bodyPaint(p))
            path.reset(); path.moveTo(130f, 61f); path.lineTo(176f, 27f); path.lineTo(174f, 84f); path.close(); c.drawPath(path, bodyPaint(p))
        } else {
            c.drawOval(RectF(32f, 52f, 73f, 132f), bodyPaint(darken(p, .76f)))
            c.drawOval(RectF(147f, 52f, 188f, 132f), bodyPaint(darken(p, .76f)))
        }
        c.drawOval(RectF(42f, 48f, 178f, 157f), bodyPaint(p))
        c.drawOval(RectF(73f, 94f, 148f, 148f), flat(lighten(p, 1.28f)))
        if (d.variant % 3 == 0) c.drawOval(RectF(48f, 55f, 91f, 106f), flat(s))
        drawFace(c, 110f, 103f, s, a, t, dog = true)
    }

    private fun drawRabbit(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        val sway = sin(t * 2f + d.variant) * 4f
        c.drawOval(RectF(58f + sway, 8f, 99f + sway, 105f), bodyPaint(p))
        c.drawOval(RectF(121f - sway, 8f, 162f - sway, 105f), bodyPaint(p))
        c.drawOval(RectF(70f + sway, 21f, 88f + sway, 90f), flat(lighten(a, 1.2f)))
        c.drawOval(RectF(132f - sway, 21f, 150f - sway, 90f), flat(lighten(a, 1.2f)))
        c.drawOval(RectF(48f, 97f, 172f, 203f), bodyPaint(p))
        c.drawOval(RectF(42f, 52f, 178f, 158f), bodyPaint(p))
        c.drawCircle(170f, 168f, 19f, flat(Color.WHITE))
        c.drawOval(RectF(58f, 177f, 102f, 210f), bodyPaint(p))
        c.drawOval(RectF(118f, 177f, 162f, 210f), bodyPaint(p))
        if (d.variant % 2 == 1) c.drawOval(RectF(72f, 58f, 104f, 92f), flat(lighten(s, 1.4f)))
        drawFace(c, 110f, 105f, s, a, t)
    }

    private fun drawBear(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        val panda = d.id.contains("panda")
        c.drawCircle(62f, 63f, 30f, bodyPaint(if (panda) s else p))
        c.drawCircle(158f, 63f, 30f, bodyPaint(if (panda) s else p))
        c.drawOval(RectF(47f, 95f, 173f, 205f), bodyPaint(p))
        c.drawOval(RectF(42f, 49f, 178f, 160f), bodyPaint(p))
        if (panda) {
            c.drawOval(RectF(60f, 74f, 101f, 120f), flat(s)); c.drawOval(RectF(119f, 74f, 160f, 120f), flat(s))
            c.drawOval(RectF(56f, 172f, 104f, 210f), bodyPaint(s)); c.drawOval(RectF(116f, 172f, 164f, 210f), bodyPaint(s))
        } else {
            c.drawOval(RectF(72f, 99f, 148f, 151f), flat(lighten(p, 1.25f)))
        }
        drawFace(c, 110f, 106f, s, a, t, dog = true)
    }

    private fun drawRodent(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        val otter = d.family == PetFamily.OTTER
        c.drawCircle(58f, 67f, if (otter) 18f else 28f, bodyPaint(p))
        c.drawCircle(162f, 67f, if (otter) 18f else 28f, bodyPaint(p))
        c.drawOval(RectF(48f, 96f, 172f, 205f), bodyPaint(p))
        c.drawOval(RectF(43f, 52f, 177f, 158f), bodyPaint(p))
        c.drawOval(RectF(70f, 94f, 150f, 151f), flat(lighten(p, 1.28f)))
        if (!otter) {
            c.drawCircle(66f, 115f, 17f, flat(lighten(a, 1.05f)))
            c.drawCircle(154f, 115f, 17f, flat(lighten(a, 1.05f)))
        } else {
            c.drawOval(RectF(73f, 153f, 147f, 184f), flat(lighten(p, 1.2f)))
            stroke.strokeWidth = 10f; stroke.color = p; c.drawArc(RectF(145f, 123f, 215f, 192f), -100f, 190f, false, stroke)
        }
        drawFace(c, 110f, 107f, s, a, t, dog = true)
    }

    private fun drawHoof(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        val sheep = d.family == PetFamily.SHEEP
        val alpaca = d.family == PetFamily.ALPACA
        val unicorn = d.family == PetFamily.UNICORN
        c.drawOval(RectF(49f, 105f, 171f, 203f), bodyPaint(p))
        c.drawOval(RectF(60f, 174f, 98f, 211f), bodyPaint(s))
        c.drawOval(RectF(122f, 174f, 160f, 211f), bodyPaint(s))
        if (alpaca) c.drawRoundRect(RectF(90f, 42f, 130f, 122f), 19f, 19f, bodyPaint(p))
        c.drawOval(RectF(43f, 47f, 177f, 157f), bodyPaint(if (sheep) lighten(p, 1.04f) else p))
        if (sheep) {
            for (i in 0..5) c.drawCircle(58f + i * 21f, 55f + (i % 2) * 4f, 18f, bodyPaint(p))
        } else {
            path.reset(); path.moveTo(58f, 64f); path.lineTo(45f, 34f); path.lineTo(84f, 57f); path.close(); c.drawPath(path, bodyPaint(p))
            path.reset(); path.moveTo(136f, 57f); path.lineTo(175f, 34f); path.lineTo(162f, 64f); path.close(); c.drawPath(path, bodyPaint(p))
        }
        if (d.family == PetFamily.DEER) {
            stroke.strokeWidth = 6f; stroke.color = s
            c.drawLine(75f, 52f, 63f, 21f, stroke); c.drawLine(63f, 27f, 51f, 18f, stroke); c.drawLine(63f, 27f, 72f, 13f, stroke)
            c.drawLine(145f, 52f, 157f, 21f, stroke); c.drawLine(157f, 27f, 169f, 18f, stroke); c.drawLine(157f, 27f, 148f, 13f, stroke)
        }
        if (unicorn) {
            path.reset(); path.moveTo(103f, 55f); path.lineTo(115f, 12f); path.lineTo(126f, 58f); path.close(); c.drawPath(path, flat(a))
        }
        drawFace(c, 110f, 104f, s, a, t)
    }

    private fun drawBird(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        val penguin = d.family == PetFamily.PENGUIN
        val owl = d.family == PetFamily.OWL
        val wing = if (action == "happy") sin(t * 9f) * 10f else sin(t * 2.5f) * 3f
        c.drawOval(RectF(47f, 52f, 173f, 205f), bodyPaint(if (penguin) s else p))
        c.drawOval(RectF(31f, 105f - wing, 78f, 170f + wing), bodyPaint(p))
        c.drawOval(RectF(142f, 105f + wing, 189f, 170f - wing), bodyPaint(p))
        if (penguin) c.drawOval(RectF(68f, 79f, 152f, 190f), flat(Color.rgb(249, 248, 242)))
        if (owl) {
            c.drawCircle(78f, 95f, 31f, flat(lighten(p, 1.18f))); c.drawCircle(142f, 95f, 31f, flat(lighten(p, 1.18f)))
        }
        drawFace(c, 110f, 105f, s, a, t)
        path.reset(); path.moveTo(99f, 120f); path.lineTo(121f, 120f); path.lineTo(110f, 135f); path.close(); c.drawPath(path, flat(Color.rgb(255, 153, 72)))
        c.drawOval(RectF(60f, 190f, 106f, 211f), flat(Color.rgb(255, 153, 72)))
        c.drawOval(RectF(114f, 190f, 160f, 211f), flat(Color.rgb(255, 153, 72)))
    }

    private fun drawPond(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        if (d.family == PetFamily.TURTLE) {
            c.drawOval(RectF(36f, 86f, 180f, 193f), bodyPaint(darken(p, .88f)))
            c.drawOval(RectF(56f, 96f, 162f, 179f), flat(p))
            stroke.strokeWidth = 3f; stroke.color = lighten(s, 1.2f)
            c.drawLine(109f, 99f, 109f, 178f, stroke); c.drawLine(59f, 137f, 159f, 137f, stroke)
            c.drawCircle(181f, 128f, 32f, bodyPaint(lighten(p, 1.05f)))
            drawFace(c, 183f, 130f, s, a, t)
            c.drawOval(RectF(48f, 169f, 85f, 202f), bodyPaint(p)); c.drawOval(RectF(133f, 169f, 170f, 202f), bodyPaint(p))
        } else {
            c.drawOval(RectF(42f, 73f, 178f, 204f), bodyPaint(p))
            c.drawCircle(75f, 64f, 31f, bodyPaint(p)); c.drawCircle(145f, 64f, 31f, bodyPaint(p))
            c.drawCircle(75f, 64f, 14f, flat(Color.WHITE)); c.drawCircle(145f, 64f, 14f, flat(Color.WHITE))
            c.drawCircle(76f, 66f, 7f, flat(s)); c.drawCircle(144f, 66f, 7f, flat(s))
            drawFace(c, 110f, 122f, s, a, t)
        }
    }

    private fun drawOcean(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        when (d.family) {
            PetFamily.OCTOPUS -> {
                c.drawOval(RectF(45f, 42f, 175f, 166f), bodyPaint(p))
                for (i in 0..4) {
                    val x = 45f + i * 31f
                    stroke.strokeWidth = 20f; stroke.color = p
                    c.drawArc(RectF(x, 137f, x + 42f, 215f), -85f, 170f, false, stroke)
                }
                drawFace(c, 110f, 105f, s, a, t)
            }
            PetFamily.WHALE -> {
                c.drawOval(RectF(30f, 71f, 185f, 188f), bodyPaint(p))
                path.reset(); path.moveTo(176f, 112f); path.lineTo(212f, 82f); path.lineTo(205f, 128f); path.lineTo(218f, 157f); path.lineTo(175f, 147f); path.close(); c.drawPath(path, bodyPaint(p))
                c.drawOval(RectF(54f, 132f, 152f, 187f), flat(lighten(p, 1.3f)))
                drawFace(c, 92f, 118f, s, a, t)
                stroke.strokeWidth = 4f; stroke.color = a; c.drawLine(96f, 72f, 87f, 50f, stroke); c.drawLine(96f, 72f, 105f, 48f, stroke)
            }
            else -> {
                c.drawOval(RectF(35f, 73f, 185f, 193f), bodyPaint(p))
                c.drawOval(RectF(62f, 123f, 158f, 190f), flat(lighten(p, 1.3f)))
                c.drawOval(RectF(29f, 151f, 77f, 202f), bodyPaint(p)); c.drawOval(RectF(143f, 151f, 191f, 202f), bodyPaint(p))
                drawFace(c, 110f, 113f, s, a, t)
            }
        }
    }

    private fun drawDino(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        val dragon = d.family == PetFamily.DRAGON
        c.drawOval(RectF(46f, 92f, 174f, 205f), bodyPaint(p))
        c.drawOval(RectF(43f, 47f, 177f, 158f), bodyPaint(p))
        c.drawOval(RectF(58f, 177f, 101f, 211f), bodyPaint(p)); c.drawOval(RectF(119f, 177f, 162f, 211f), bodyPaint(p))
        for (i in 0..4) {
            path.reset(); path.moveTo(62f + i * 24f, 64f); path.lineTo(72f + i * 24f, 37f - (i % 2) * 5f); path.lineTo(84f + i * 24f, 66f); path.close(); c.drawPath(path, flat(a))
        }
        if (dragon) {
            path.reset(); path.moveTo(54f, 118f); path.lineTo(16f, 97f); path.lineTo(40f, 151f); path.close(); c.drawPath(path, bodyPaint(lighten(p, 1.08f)))
            path.reset(); path.moveTo(166f, 118f); path.lineTo(204f, 97f); path.lineTo(180f, 151f); path.close(); c.drawPath(path, bodyPaint(lighten(p, 1.08f)))
            path.reset(); path.moveTo(64f, 58f); path.lineTo(56f, 27f); path.lineTo(82f, 56f); path.close(); c.drawPath(path, flat(a))
            path.reset(); path.moveTo(138f, 56f); path.lineTo(164f, 27f); path.lineTo(156f, 58f); path.close(); c.drawPath(path, flat(a))
        }
        drawFace(c, 110f, 104f, s, a, t)
    }

    private fun drawFantasy(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        when (d.family) {
            PetFamily.SLIME -> {
                val sq = sin(t * 3f) * 5f
                path.reset(); path.moveTo(35f, 184f); path.quadTo(39f, 70f - sq, 110f, 62f + sq); path.quadTo(181f, 70f - sq, 185f, 184f)
                path.quadTo(167f, 208f, 146f, 188f); path.quadTo(128f, 209f, 110f, 190f); path.quadTo(91f, 209f, 73f, 188f); path.quadTo(52f, 208f, 35f, 184f); path.close(); c.drawPath(path, bodyPaint(p))
                c.drawOval(RectF(61f, 86f, 94f, 103f), flat(0x66FFFFFF))
                drawFace(c, 110f, 133f, s, a, t)
            }
            PetFamily.GHOST -> {
                path.reset(); path.moveTo(42f, 189f); path.lineTo(42f, 108f); path.cubicTo(42f, 45f, 73f, 25f, 110f, 25f); path.cubicTo(147f, 25f, 178f, 45f, 178f, 108f); path.lineTo(178f, 189f)
                path.quadTo(161f, 211f, 144f, 189f); path.quadTo(127f, 211f, 110f, 189f); path.quadTo(93f, 211f, 76f, 189f); path.quadTo(59f, 211f, 42f, 189f); path.close(); c.drawPath(path, bodyPaint(p))
                drawFace(c, 110f, 106f, s, a, t)
            }
            PetFamily.CLOUD -> {
                c.drawCircle(68f, 116f, 43f, bodyPaint(p)); c.drawCircle(107f, 90f, 54f, bodyPaint(p)); c.drawCircle(151f, 115f, 43f, bodyPaint(p)); c.drawOval(RectF(47f, 112f, 174f, 186f), bodyPaint(p))
                drawFace(c, 110f, 137f, s, a, t)
                if (d.variant == 1) {
                    stroke.strokeWidth = 5f; stroke.color = a
                    for (x in listOf(72f, 110f, 148f)) c.drawLine(x, 184f, x - 7f, 211f, stroke)
                }
            }
            PetFamily.STAR -> {
                val outer = 88f; val inner = 46f
                path.reset()
                for (i in 0 until 10) {
                    val angle = -Math.PI / 2 + i * Math.PI / 5
                    val r = if (i % 2 == 0) outer else inner
                    val x = 110f + cos(angle).toFloat() * r
                    val y = 112f + sin(angle).toFloat() * r
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close(); c.drawPath(path, bodyPaint(p))
                drawFace(c, 110f, 113f, s, a, t)
            }
            else -> {
                val bob = sin(t * 2.7f) * 5f
                c.drawOval(RectF(49f, 59f + bob, 171f, 194f + bob), bodyPaint(p))
                path.reset(); path.moveTo(70f, 75f + bob); path.lineTo(54f, 35f + bob); path.lineTo(92f, 61f + bob); path.close(); c.drawPath(path, flat(a))
                path.reset(); path.moveTo(128f, 61f + bob); path.lineTo(166f, 35f + bob); path.lineTo(150f, 75f + bob); path.close(); c.drawPath(path, flat(a))
                drawFace(c, 110f, 116f + bob, s, a, t)
            }
        }
    }

    private fun drawRobot(c: Canvas, d: PetDefinition, p: Int, s: Int, a: Int, t: Float) {
        if (d.family == PetFamily.ALIEN) {
            c.drawOval(RectF(44f, 45f, 176f, 174f), bodyPaint(p))
            c.drawOval(RectF(58f, 145f, 162f, 205f), bodyPaint(p))
            c.drawOval(RectF(59f, 78f, 97f, 121f), flat(s)); c.drawOval(RectF(123f, 78f, 161f, 121f), flat(s))
            c.drawCircle(78f, 94f, 8f, flat(Color.WHITE)); c.drawCircle(142f, 94f, 8f, flat(Color.WHITE))
            stroke.strokeWidth = 4f; stroke.color = s; c.drawArc(RectF(90f, 122f, 130f, 147f), 10f, 160f, false, stroke)
            stroke.strokeWidth = 5f; c.drawLine(76f, 51f, 61f, 20f, stroke); c.drawCircle(58f, 17f, 7f, flat(a)); c.drawLine(144f, 51f, 159f, 20f, stroke); c.drawCircle(162f, 17f, 7f, flat(a))
        } else {
            stroke.strokeWidth = 5f; stroke.color = s; c.drawLine(110f, 31f, 110f, 51f, stroke); c.drawCircle(110f, 24f, 10f, flat(a))
            c.drawRoundRect(RectF(42f, 48f, 178f, 150f), 25f, 25f, bodyPaint(p))
            c.drawRoundRect(RectF(55f, 63f, 165f, 132f), 17f, 17f, flat(darken(p, .70f)))
            c.drawRoundRect(RectF(56f, 143f, 164f, 200f), 18f, 18f, bodyPaint(p))
            c.drawRoundRect(RectF(33f, 145f, 62f, 187f), 12f, 12f, bodyPaint(p)); c.drawRoundRect(RectF(158f, 145f, 187f, 187f), 12f, 12f, bodyPaint(p))
            c.drawRoundRect(RectF(67f, 190f, 104f, 212f), 10f, 10f, bodyPaint(s)); c.drawRoundRect(RectF(116f, 190f, 153f, 212f), 10f, 10f, bodyPaint(s))
            drawFace(c, 110f, 101f, Color.WHITE, a, t)
            c.drawCircle(110f, 170f, 10f, flat(a))
        }
    }

    private fun drawMarkings(c: Canvas, variant: Int, p: Int, s: Int, a: Int) {
        when (variant % 8) {
            0 -> { c.drawOval(RectF(54f, 57f, 98f, 96f), flat(s)); c.drawOval(RectF(132f, 107f, 165f, 142f), flat(s)) }
            1 -> { stroke.strokeWidth = 5f; stroke.color = darken(p, .72f); c.drawLine(79f, 52f, 75f, 79f, stroke); c.drawLine(106f, 48f, 105f, 75f, stroke); c.drawLine(134f, 53f, 140f, 80f, stroke) }
            2 -> c.drawOval(RectF(49f, 51f, 171f, 85f), flat(lighten(s, 1.12f)))
            3 -> c.drawCircle(83f, 76f, 15f, flat(a))
            4 -> { c.drawOval(RectF(61f, 55f, 102f, 101f), flat(s)); c.drawOval(RectF(119f, 108f, 165f, 145f), flat(lighten(a, 1.1f))) }
            5 -> { for (i in 0..4) c.drawCircle(63f + i * 23f, 62f + (i % 2) * 10f, 6f, flat(s)) }
            6 -> { c.drawOval(RectF(51f, 57f, 91f, 95f), flat(Color.rgb(223, 135, 73))); c.drawOval(RectF(129f, 61f, 168f, 103f), flat(s)) }
            7 -> { c.drawOval(RectF(47f, 50f, 173f, 76f), flat(darken(p, .85f))); c.drawCircle(68f, 112f, 9f, flat(a)); c.drawCircle(151f, 124f, 7f, flat(a)) }
        }
    }

    private fun drawWhiskers(c: Canvas, color: Int) {
        stroke.strokeWidth = 2.2f; stroke.color = darken(color, .78f)
        listOf(-9f, 0f, 9f).forEach { dy ->
            c.drawLine(75f, 114f + dy, 32f, 107f + dy * 1.25f, stroke)
            c.drawLine(145f, 114f + dy, 188f, 107f + dy * 1.25f, stroke)
        }
    }

    private fun drawFace(c: Canvas, cx: Float, cy: Float, dark: Int, accent: Int, t: Float, dog: Boolean = false) {
        val exp = forcedExpression ?: slot.expression
        val blink = animationEnabled && (t % 4.2f) > 4.03f
        val eyeY = cy - 13f
        stroke.strokeWidth = 4.2f; stroke.color = dark; stroke.shader = null
        when {
            exp == 2 || blink -> {
                c.drawArc(RectF(cx - 41f, eyeY - 5f, cx - 15f, eyeY + 11f), 7f, 166f, false, stroke)
                c.drawArc(RectF(cx + 15f, eyeY - 5f, cx + 41f, eyeY + 11f), 7f, 166f, false, stroke)
            }
            exp == 4 -> {
                c.drawLine(cx - 39f, eyeY, cx - 17f, eyeY + 3f, stroke); c.drawLine(cx + 17f, eyeY + 3f, cx + 39f, eyeY, stroke)
            }
            exp == 5 -> {
                c.drawLine(cx - 40f, eyeY - 8f, cx - 18f, eyeY + 1f, stroke); c.drawLine(cx + 18f, eyeY + 1f, cx + 40f, eyeY - 8f, stroke)
                c.drawCircle(cx - 29f, eyeY + 7f, 5f, flat(dark)); c.drawCircle(cx + 29f, eyeY + 7f, 5f, flat(dark))
            }
            exp == 6 -> {
                c.drawCircle(cx - 29f, eyeY, 9f, stroke); c.drawCircle(cx + 29f, eyeY, 9f, stroke)
            }
            exp == 7 -> { drawHeart(c, cx - 29f, eyeY, 10f, accent); drawHeart(c, cx + 29f, eyeY, 10f, accent) }
            exp == 8 -> { drawStar(c, cx - 29f, eyeY, 10f, accent); drawStar(c, cx + 29f, eyeY, 10f, accent) }
            exp == 9 -> {
                c.drawOval(RectF(cx - 36f, eyeY - 7f, cx - 21f, eyeY + 10f), flat(dark)); c.drawOval(RectF(cx + 21f, eyeY - 7f, cx + 36f, eyeY + 10f), flat(dark))
                c.drawCircle(cx - 29f, eyeY + 15f, 3f, flat(Color.rgb(104, 186, 255))); c.drawCircle(cx + 29f, eyeY + 15f, 3f, flat(Color.rgb(104, 186, 255)))
            }
            else -> {
                c.drawOval(RectF(cx - 37f, eyeY - 9f, cx - 20f, eyeY + 11f), flat(dark)); c.drawOval(RectF(cx + 20f, eyeY - 9f, cx + 37f, eyeY + 11f), flat(dark))
                c.drawCircle(cx - 31f, eyeY - 3f, 3.5f, flat(Color.WHITE)); c.drawCircle(cx + 26f, eyeY - 3f, 3.5f, flat(Color.WHITE))
            }
        }
        if (exp == 3) {
            c.drawCircle(cx - 48f, cy + 8f, 10f, flat(0x77FF749F)); c.drawCircle(cx + 48f, cy + 8f, 10f, flat(0x77FF749F))
        }
        if (dog) c.drawOval(RectF(cx - 8f, cy - 2f, cx + 8f, cy + 10f), flat(dark))
        else {
            path.reset(); path.moveTo(cx - 7f, cy - 2f); path.lineTo(cx + 7f, cy - 2f); path.lineTo(cx, cy + 7f); path.close(); c.drawPath(path, flat(accent))
        }
        stroke.strokeWidth = 3.2f; stroke.color = dark
        when (exp) {
            5 -> c.drawArc(RectF(cx - 15f, cy + 13f, cx + 15f, cy + 28f), 190f, 160f, false, stroke)
            6 -> c.drawOval(RectF(cx - 8f, cy + 11f, cx + 8f, cy + 28f), flat(dark))
            10 -> c.drawArc(RectF(cx - 18f, cy + 7f, cx + 18f, cy + 31f), 5f, 170f, false, stroke)
            else -> { c.drawArc(RectF(cx - 17f, cy + 6f, cx, cy + 23f), 0f, 100f, false, stroke); c.drawArc(RectF(cx, cy + 6f, cx + 17f, cy + 23f), 80f, 100f, false, stroke) }
        }
    }

    private fun drawAccessory(c: Canvas, accessory: Accessory, p: Int, s: Int, a: Int, t: Float) {
        when (accessory) {
            Accessory.NONE -> Unit
            Accessory.BELL -> { stroke.strokeWidth = 7f; stroke.color = a; c.drawLine(69f, 146f, 151f, 146f, stroke); c.drawCircle(110f, 155f, 10f, flat(Color.rgb(255, 207, 63))) }
            Accessory.BOW, Accessory.RIBBON -> { c.drawOval(RectF(72f, 28f, 109f, 58f), flat(a)); c.drawOval(RectF(111f, 28f, 148f, 58f), flat(a)); c.drawCircle(110f, 43f, 10f, flat(lighten(a, 1.15f))) }
            Accessory.FLOWER -> { for (i in 0..4) { val ang = i * Math.PI * 2 / 5; c.drawCircle(155f + cos(ang).toFloat()*12f, 54f + sin(ang).toFloat()*12f, 9f, flat(a)) }; c.drawCircle(155f, 54f, 7f, flat(Color.rgb(255, 220, 90))) }
            Accessory.LEAF -> { c.drawOval(RectF(143f, 35f, 177f, 60f), flat(a)); stroke.strokeWidth = 2.5f; stroke.color = darken(a, .72f); c.drawLine(147f, 55f, 173f, 40f, stroke) }
            Accessory.CROWN -> { path.reset(); path.moveTo(77f, 52f); path.lineTo(80f, 22f); path.lineTo(96f, 38f); path.lineTo(110f, 17f); path.lineTo(125f, 38f); path.lineTo(141f, 22f); path.lineTo(144f, 52f); path.close(); c.drawPath(path, flat(Color.rgb(255, 211, 70))); c.drawCircle(110f, 28f, 4f, flat(a)) }
            Accessory.SCARF -> { stroke.strokeWidth = 11f; stroke.color = a; c.drawLine(69f, 149f, 151f, 149f, stroke); path.reset(); path.moveTo(132f, 151f); path.lineTo(158f, 191f); path.lineTo(136f, 181f); path.close(); c.drawPath(path, flat(a)) }
            Accessory.GLASSES -> { stroke.strokeWidth = 4f; stroke.color = darken(s, .65f); c.drawCircle(81f, 90f, 23f, stroke); c.drawCircle(139f, 90f, 23f, stroke); c.drawLine(104f, 90f, 116f, 90f, stroke) }
            Accessory.HEART -> drawHeart(c, 154f, 48f, 15f, a)
            Accessory.STAR -> drawStar(c, 157f, 49f, 15f, a)
            Accessory.CAP -> { c.drawArc(RectF(67f, 23f, 153f, 74f), 180f, 180f, true, flat(a)); c.drawRoundRect(RectF(110f, 49f, 174f, 61f), 6f, 6f, flat(a)) }
            Accessory.HEADPHONES -> { stroke.strokeWidth = 8f; stroke.color = a; c.drawArc(RectF(57f, 38f, 163f, 126f), 195f, 150f, false, stroke); c.drawRoundRect(RectF(45f, 76f, 65f, 120f), 8f, 8f, flat(a)); c.drawRoundRect(RectF(155f, 76f, 175f, 120f), 8f, 8f, flat(a)) }
            Accessory.HALO -> { stroke.strokeWidth = 6f; stroke.color = Color.rgb(255, 231, 125); c.drawOval(RectF(70f, 16f, 150f, 42f), stroke) }
            Accessory.BACKPACK -> { c.drawRoundRect(RectF(151f, 118f, 197f, 183f), 13f, 13f, flat(a)); stroke.strokeWidth = 5f; stroke.color = darken(a, .72f); c.drawArc(RectF(145f, 109f, 187f, 160f), 190f, 150f, false, stroke) }
            Accessory.GEM -> { path.reset(); path.moveTo(110f, 144f); path.lineTo(124f, 158f); path.lineTo(110f, 178f); path.lineTo(96f, 158f); path.close(); c.drawPath(path, flat(a)); c.drawCircle(106f, 153f, 3f, flat(Color.WHITE)) }
        }
    }

    private fun drawHeart(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        path.reset(); path.moveTo(x, y + r); path.cubicTo(x - r * 1.6f, y, x - r * .9f, y - r, x, y - r * .25f); path.cubicTo(x + r * .9f, y - r, x + r * 1.6f, y, x, y + r); path.close(); c.drawPath(path, flat(color))
    }

    private fun drawStar(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        path.reset()
        for (i in 0 until 10) {
            val angle = -Math.PI / 2 + i * Math.PI / 5
            val rr = if (i % 2 == 0) r else r * .45f
            val px = x + cos(angle).toFloat() * rr
            val py = y + sin(angle).toFloat() * rr
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close(); c.drawPath(path, flat(color))
    }

    private fun lighten(color: Int, factor: Float): Int = Color.rgb(
        (Color.red(color) * factor).toInt().coerceIn(0,255),
        (Color.green(color) * factor).toInt().coerceIn(0,255),
        (Color.blue(color) * factor).toInt().coerceIn(0,255)
    )
    private fun darken(color: Int, factor: Float): Int = lighten(color, factor)
}
