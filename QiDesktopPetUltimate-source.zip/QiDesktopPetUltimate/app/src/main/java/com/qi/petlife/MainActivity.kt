package com.qi.petlife

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    companion object {
        private const val REQ_IMAGE = 501
        private const val REQ_EXPORT = 502
        private const val REQ_IMPORT = 503
    }

    private lateinit var root: LinearLayout
    private lateinit var preview: PetCanvasView
    private var config = AppConfig()
    private val paletteTriples = listOf(
        Triple(0xFFFFF9F4.toInt(), 0xFF3D3946.toInt(), 0xFFFF91B5.toInt()),
        Triple(0xFFF6A14B.toInt(), 0xFF7F472D.toInt(), 0xFFFFD267.toInt()),
        Triple(0xFFAEE7D5.toInt(), 0xFF37675E.toInt(), 0xFFFFF2A3.toInt()),
        Triple(0xFFC8B5F6.toInt(), 0xFF574B78.toInt(), 0xFFFFB6D2.toInt()),
        Triple(0xFF89C8F0.toInt(), 0xFF355A75.toInt(), 0xFFD6F4FF.toInt()),
        Triple(0xFFF3B5CB.toInt(), 0xFF7F5269.toInt(), 0xFFFFF2A4.toInt()),
        Triple(0xFFDDBA91.toInt(), 0xFF624A3D.toInt(), 0xFFF9D55C.toInt()),
        Triple(0xFF35313F.toInt(), 0xFF16141C.toInt(), 0xFF9DD8FF.toInt()),
        Triple(0xFFFFD878.toInt(), 0xFF815A2F.toInt(), 0xFFFF8FA0.toInt()),
        Triple(0xFFE4EAF3.toInt(), 0xFF606A7D.toInt(), 0xFFB8E8FF.toInt()),
        Triple(0xFF8CDBBE.toInt(), 0xFF365E54.toInt(), 0xFFD9FF9D.toInt()),
        Triple(0xFFF3C1D2.toInt(), 0xFF755366.toInt(), 0xFFFFF2A4.toInt())
    )

    private val slot: PetSlot get() = config.slots[config.selectedSlot]

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        config = PetPrefs.load(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::preview.isInitialized) updatePreview()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(248, 245, 255))
            isFillViewport = true
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(this@MainActivity, 16), dp(this@MainActivity, 18), dp(this@MainActivity, 16), dp(this@MainActivity, 28))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(TextView(this).apply { text = "Qi 桌面宠物 · 最终版"; titleStyle(27f) })
        root.addView(TextView(this).apply {
            text = "超大宠物库｜主动说话｜养成互动｜多宠物｜自定义透明素材"
            textSize = 13f; setTextColor(Color.rgb(100, 88, 124)); setPadding(0, dp(this@MainActivity, 4), 0, dp(this@MainActivity, 12))
        })

        preview = PetCanvasView(this).apply {
            slot = this@MainActivity.slot.copy()
            background = rounded(Color.WHITE, 24, Color.rgb(228, 220, 244), 1, this@MainActivity)
        }
        root.addView(preview, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(this, 270)).apply { bottomMargin = dp(this@MainActivity, 14) })

        addQuickStartCard()
        addPetLibraryCard()
        addAppearanceCard()
        addSpeechCard()
        addLifeCard()
        addCustomMediaCard()
        addSystemCard()
        addBottomActions()
    }

    private fun addQuickStartCard() = section("多宠物管理") {
        addSpinner("正在编辑", listOf("宠物 1", "宠物 2", "宠物 3", "宠物 4"), config.selectedSlot) { pos ->
            config.selectedSlot = pos
            save()
            recreate()
        }
        addSpinner("同时显示数量", listOf("1 只", "2 只", "3 只", "4 只"), config.activeCount - 1) { pos ->
            config.activeCount = pos + 1
            config.normalize(); save(); toast("已设置同时显示 ${pos + 1} 只宠物")
        }
        addEdit("宠物名字", slot.name, singleLine = true) {
            slot.name = it.take(18); save()
        }
        addText("每只宠物都能独立选择造型、名字、性格、大小、动作、台词与位置。")
    }

    private fun addPetLibraryCard() = section("超大宠物库") {
        val current = PetCatalog.get(slot.petId)
        val categorySpinner = Spinner(this@MainActivity)
        val petSpinner = Spinner(this@MainActivity)
        addView(label("分类"))
        categorySpinner.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, PetCatalog.categories)
        val categoryIndex = PetCatalog.categories.indexOf(current.category).coerceAtLeast(0)
        categorySpinner.setSelection(categoryIndex)
        addView(categorySpinner, fieldParams())
        addView(label("宠物造型"))
        fun loadPets(category: String, selectId: String? = null) {
            val pets = PetCatalog.filtered(category)
            petSpinner.adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, pets.map { it.name })
            val index = pets.indexOfFirst { it.id == selectId }.coerceAtLeast(0)
            petSpinner.setSelection(index)
        }
        loadPets(current.category, slot.petId)
        addView(petSpinner, fieldParams())
        var firstCategory = true
        categorySpinner.onItemSelectedListener = spinnerListener { pos ->
            if (firstCategory) firstCategory = false else loadPets(PetCatalog.categories[pos], null)
        }
        var firstPet = true
        petSpinner.onItemSelectedListener = spinnerListener { pos ->
            if (firstPet) firstPet = false else {
                val category = PetCatalog.categories[categorySpinner.selectedItemPosition]
                val pets = PetCatalog.filtered(category)
                val pet = pets.getOrNull(pos)
                if (pet != null) {
                    slot.petId = pet.id
                    if (pet.id != "custom") slot.customUri = ""
                    saveUpdate()
                }
            }
        }
        addSpinner("默认表情", PetText.expressions, slot.expression) { slot.expression = it; saveUpdate() }
        addSpinner("性格", PetText.personalities, slot.personality) { slot.personality = it; save() }
        addText("当前内置 ${PetCatalog.all.size - 1} 种精致宠物造型，覆盖猫狗、森林动物、鸟类、海洋生物、恐龙、精灵、幻想生物与机器人。")
    }

    private fun addAppearanceCard() = section("外观与动画") {
        addSeek("宠物大小", slot.sizeDp, 72, 300, "dp") { slot.sizeDp = it; saveUpdate() }
        addSeek("透明度", slot.opacity, 25, 100, "%") { slot.opacity = it; saveUpdate() }
        addSwitch("使用自定义配色", slot.useCustomColors) { slot.useCustomColors = it; saveUpdate() }
        addText("快速配色方案")
        val colors = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
        paletteTriples.forEach { triple ->
            colors.addView(View(this@MainActivity).apply {
                background = GradientDrawable().apply {
                    orientation = GradientDrawable.Orientation.TL_BR
                    setColors(intArrayOf(triple.first, triple.third))
                    cornerRadius = dp(this@MainActivity, 99).toFloat()
                    setStroke(dp(this@MainActivity, 1), Color.rgb(208, 201, 220))
                }
                setOnClickListener {
                    slot.useCustomColors = true
                    slot.primaryColor = triple.first; slot.secondaryColor = triple.second; slot.accentColor = triple.third
                    saveUpdate()
                }
            }, LinearLayout.LayoutParams(dp(this@MainActivity, 38), dp(this@MainActivity, 38)).apply { rightMargin = dp(this@MainActivity, 7) })
        }
        addView(HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false; addView(colors) }, LinearLayout.LayoutParams(-1, dp(this@MainActivity, 48)))
        addSwitch("柔和投影", slot.shadow) { slot.shadow = it; saveUpdate() }
        addSwitch("卡通描边", slot.outline) { slot.outline = it; saveUpdate() }
        addSwitch("左右翻转", slot.mirror) { slot.mirror = it; saveUpdate() }
        addSwitch("自动散步", slot.autoWalk) { slot.autoWalk = it; save() }
        addSwitch("碰到屏幕边缘转身", slot.bounceEdges) { slot.bounceEdges = it; save() }
        addSeek("移动速度", slot.speed, 1, 100, "") { slot.speed = it; save() }
        addSeek("活跃程度", slot.activity, 0, 100, "%") { slot.activity = it; save() }
    }

    private fun addSpeechCard() = section("主动说话与文字气泡") {
        addSwitch("宠物主动冒文字", config.speechEnabled) { config.speechEnabled = it; save() }
        addSpinner("说话频率", PetText.speechLevels, config.speechLevel) { config.speechLevel = it; save() }
        addSpinner("气泡样式", PetText.bubbleStyles, slot.bubbleStyle) { slot.bubbleStyle = it; save() }
        addSwitch("朗读文字（系统语音）", config.ttsEnabled) { config.ttsEnabled = it; save() }
        addSeek("朗读速度", config.ttsRate, 60, 140, "%") { config.ttsRate = it; save() }
        addEdit("宠物对你的称呼", config.ownerName, singleLine = true) { config.ownerName = it.take(16); save() }
        addEdit("自定义台词（一行一句）", slot.customLines, singleLine = false) { slot.customLines = it.take(2000); save() }
        addSwitch("多宠物互相说话", config.multiPetTalk) { config.multiPetTalk = it; save() }
        addText("台词会根据时间、电量、充电、解锁、心情、饥饿、连续点击和宠物性格自动变化，并尽量避免短时间重复。")
    }

    private fun addLifeCard() = section("养成、互动与日记") {
        addSwitch("启用心情与养成状态", config.needsEnabled) { config.needsEnabled = it; save() }
        addStatus("心情", slot.mood)
        addStatus("饥饿度", slot.hunger)
        addStatus("精力", slot.energy)
        addStatus("清洁度", slot.cleanliness)
        addText("亲密度：${slot.affection}")
        val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(smallButton("喂食") {
            slot.hunger = (slot.hunger - 30).coerceAtLeast(0); slot.mood = (slot.mood + 6).coerceAtMost(100); slot.affection += 2
            JournalStore.append(this@MainActivity, slot.name, "你给它喂了好吃的。"); save(); recreate()
        }, LinearLayout.LayoutParams(0, dp(this@MainActivity, 45), 1f).apply { rightMargin = dp(this@MainActivity, 5) })
        row.addView(smallButton("抚摸") {
            slot.mood = (slot.mood + 8).coerceAtMost(100); slot.affection += 3
            JournalStore.append(this@MainActivity, slot.name, "你摸了摸它的头。"); save(); recreate()
        }, LinearLayout.LayoutParams(0, dp(this@MainActivity, 45), 1f).apply { leftMargin = dp(this@MainActivity, 5); rightMargin = dp(this@MainActivity, 5) })
        row.addView(smallButton("清洁") {
            slot.cleanliness = 100; slot.mood = (slot.mood + 3).coerceAtMost(100)
            JournalStore.append(this@MainActivity, slot.name, "洗得干干净净。 "); save(); recreate()
        }, LinearLayout.LayoutParams(0, dp(this@MainActivity, 45), 1f).apply { leftMargin = dp(this@MainActivity, 5) })
        addView(row)
        addSwitch("记录宠物日记", config.journalEnabled) { config.journalEnabled = it; save() }
        addButton("查看宠物日记") { showJournal() }
    }

    private fun addCustomMediaCard() = section("自定义宠物素材") {
        addButton("从手机上传 PNG / JPG / WebP / GIF") { chooseImage() }
        addButton("清除当前自定义素材") {
            slot.customUri = ""
            if (slot.petId == "custom") slot.petId = "cat_milk"
            save(); recreate()
        }
        addText("透明 PNG 会直接保留透明区域，不添加白框、黑框或底板；静态透明图片会自动裁掉多余透明空白。Android 9 及以上还能播放 GIF 和动态 WebP。")
    }

    private fun addSystemCard() = section("小米 MIUI / HyperOS 与数据") {
        addSwitch("开机后自动启动", config.autoStart) { config.autoStart = it; save() }
        addSwitch("锁屏时暂停动画", config.pauseOnLock) { config.pauseOnLock = it; save() }
        addSwitch("省电模式（推荐）", config.lowPowerMode) { config.lowPowerMode = it; save() }
        addButton("开启 / 检查悬浮窗权限") { openOverlayPermission() }
        addButton("打开应用系统设置") { openAppSettings() }
        addButton("尝试打开小米自启动管理") { openMiuiAutostart() }
        addButton("导出全部配置") { exportConfig() }
        addButton("导入配置") { importConfig() }
        addText("小米手机建议：允许悬浮窗、自启动；电池与性能中的省电策略设为“无限制”；在最近任务中锁定本应用。")
    }

    private fun addBottomActions() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(actionButton("启动 / 更新宠物", Color.rgb(112, 82, 220)) { startPet() }, LinearLayout.LayoutParams(0, dp(this, 54), 1f).apply { rightMargin = dp(this@MainActivity, 6) })
        row.addView(actionButton("关闭宠物", Color.rgb(74, 69, 86)) { stopPet() }, LinearLayout.LayoutParams(0, dp(this, 54), 1f).apply { leftMargin = dp(this@MainActivity, 6) })
        root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(this@MainActivity, 4) })
        root.addView(actionButton("恢复全部默认设置", Color.rgb(225, 92, 112)) {
            AlertDialog.Builder(this).setTitle("恢复默认设置？").setMessage("宠物配置会恢复初始状态，日记不会删除。")
                .setNegativeButton("取消", null).setPositiveButton("恢复") { _, _ -> config = AppConfig().normalize(); save(); recreate() }.show()
        }, LinearLayout.LayoutParams(-1, dp(this, 48)).apply { topMargin = dp(this@MainActivity, 10) })
    }

    private fun section(title: String, block: LinearLayout.() -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 20, Color.rgb(230, 223, 245), 1, this@MainActivity)
            setPadding(dp(this@MainActivity, 14), dp(this@MainActivity, 13), dp(this@MainActivity, 14), dp(this@MainActivity, 13))
            addView(TextView(this@MainActivity).apply { text = title; titleStyle(18f) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(this@MainActivity, 8) })
            block()
        }
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(this@MainActivity, 13) })
    }

    private fun LinearLayout.addText(textValue: String) {
        addView(TextView(this@MainActivity).apply {
            text = textValue; textSize = 13f; setTextColor(Color.rgb(102, 92, 122)); setPadding(0, dp(this@MainActivity, 5), 0, dp(this@MainActivity, 6))
        })
    }

    private fun LinearLayout.addStatus(name: String, value: Int) {
        val line = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        line.addView(TextView(this@MainActivity).apply { text = name; textSize = 14f; setTextColor(Color.rgb(63, 56, 76)) }, LinearLayout.LayoutParams(dp(this@MainActivity, 70), -2))
        line.addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = value }, LinearLayout.LayoutParams(0, dp(this@MainActivity, 22), 1f))
        line.addView(TextView(this@MainActivity).apply { text = "$value"; gravity = Gravity.END; setTextColor(Color.rgb(112, 82, 220)) }, LinearLayout.LayoutParams(dp(this@MainActivity, 42), -2))
        addView(line, LinearLayout.LayoutParams(-1, dp(this@MainActivity, 34)))
    }

    private fun LinearLayout.addSpinner(label: String, values: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        addView(label(label))
        val spinner = Spinner(this@MainActivity).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, values)
            setSelection(selected.coerceIn(0, values.lastIndex.coerceAtLeast(0)))
            background = rounded(Color.rgb(248, 246, 252), 12, Color.rgb(225, 219, 235), 1, this@MainActivity)
        }
        var first = true
        spinner.onItemSelectedListener = spinnerListener { pos -> if (first) first = false else onSelect(pos) }
        addView(spinner, fieldParams())
    }

    private fun LinearLayout.addSeek(label: String, value: Int, min: Int, max: Int, suffix: String, onChange: (Int) -> Unit) {
        val head = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(this@MainActivity.label(label), LinearLayout.LayoutParams(0, -2, 1f))
        val number = TextView(this@MainActivity).apply { text = "$value$suffix"; textSize = 14f; setTextColor(Color.rgb(112, 82, 220)) }
        head.addView(number)
        addView(head)
        addView(SeekBar(this@MainActivity).apply {
            this.max = max - min; progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val n = progress + min; number.text = "$n$suffix"; if (fromUser) onChange(n)
                }
            })
        }, LinearLayout.LayoutParams(-1, dp(this@MainActivity, 40)))
    }

    private fun LinearLayout.addSwitch(textValue: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        addView(Switch(this@MainActivity).apply {
            text = textValue; textSize = 15f; isChecked = checked; setTextColor(Color.rgb(58, 51, 72))
            setOnCheckedChangeListener { _, value -> onChange(value) }
        }, LinearLayout.LayoutParams(-1, dp(this@MainActivity, 48)))
    }

    private fun LinearLayout.addEdit(labelText: String, initial: String, singleLine: Boolean, onChange: (String) -> Unit) {
        addView(label(labelText))
        val edit = EditText(this@MainActivity).apply {
            setText(initial); textSize = 14f; setTextColor(Color.rgb(54, 49, 67)); setHintTextColor(Color.LTGRAY)
            setSingleLine(singleLine); minLines = if (singleLine) 1 else 4; gravity = if (singleLine) Gravity.CENTER_VERTICAL else Gravity.TOP
            background = rounded(Color.rgb(248, 246, 252), 12, Color.rgb(225, 219, 235), 1, this@MainActivity)
            setPadding(dp(this@MainActivity, 12), dp(this@MainActivity, 8), dp(this@MainActivity, 12), dp(this@MainActivity, 8))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = onChange(s?.toString().orEmpty())
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        addView(edit, LinearLayout.LayoutParams(-1, if (singleLine) dp(this@MainActivity, 48) else dp(this@MainActivity, 112)).apply { bottomMargin = dp(this@MainActivity, 8) })
    }

    private fun LinearLayout.addButton(textValue: String, onClick: () -> Unit) {
        addView(actionButton(textValue, Color.rgb(122, 91, 222), onClick), LinearLayout.LayoutParams(-1, dp(this@MainActivity, 46)).apply { bottomMargin = dp(this@MainActivity, 7) })
    }

    private fun label(value: String) = TextView(this).apply {
        text = value; textSize = 14f; setTextColor(Color.rgb(70, 62, 84)); setPadding(0, dp(this@MainActivity, 5), 0, dp(this@MainActivity, 4))
    }

    private fun fieldParams() = LinearLayout.LayoutParams(-1, dp(this, 48)).apply { bottomMargin = dp(this@MainActivity, 8) }

    private fun spinnerListener(block: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = block(position)
    }

    private fun actionButton(textValue: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = textValue; textSize = 15f; setTextColor(Color.WHITE); isAllCaps = false
        background = rounded(color, 14, context = this@MainActivity)
        setOnClickListener { onClick() }
    }

    private fun smallButton(textValue: String, onClick: () -> Unit) = actionButton(textValue, Color.rgb(124, 94, 218), onClick)

    private fun save() = PetPrefs.save(this, config)
    private fun saveUpdate() { save(); updatePreview() }
    private fun updatePreview() { preview.slot = slot.copy(); preview.invalidate() }
    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    private fun chooseImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQ_IMAGE)
    }

    private fun exportConfig() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"; putExtra(Intent.EXTRA_TITLE, "QiDesktopPet-config.json")
        }, REQ_EXPORT)
    }

    private fun importConfig() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/json"
        }, REQ_IMPORT)
    }

    @Deprecated("Legacy result API retained for Android 8 compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_IMAGE -> {
                runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                slot.customUri = uri.toString(); slot.petId = "custom"; save(); recreate()
            }
            REQ_EXPORT -> runCatching {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(PetPrefs.exportText(config)) }
                toast("配置已导出")
            }.onFailure { toast("导出失败：${it.message}") }
            REQ_IMPORT -> runCatching {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("文件为空")
                config = PetPrefs.importText(text); save(); recreate()
            }.onFailure { toast("导入失败：${it.message}") }
        }
    }

    private fun startPet() {
        save()
        if (!Settings.canDrawOverlays(this)) { openOverlayPermission(); toast("先允许悬浮窗权限，再返回点击启动"); return }
        val intent = Intent(this, OverlayPetService::class.java).setAction(OverlayPetService.ACTION_REFRESH)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        toast("桌面宠物已启动或更新")
    }

    private fun stopPet() {
        startService(Intent(this, OverlayPetService::class.java).setAction(OverlayPetService.ACTION_STOP))
        toast("桌面宠物已关闭")
    }

    private fun openOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun openMiuiAutostart() {
        val attempts = listOf(
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
            Intent().setComponent(ComponentName("com.miui.securitycenter", "com.miui.powercenter.PowerSettings")),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
        val launched = attempts.any { runCatching { startActivity(it); true }.getOrDefault(false) }
        if (!launched) toast("请在系统设置里手动打开自启动和无限制省电")
    }

    private fun showJournal() {
        val text = TextView(this).apply {
            this.text = JournalStore.recentText(this@MainActivity); textSize = 14f; setTextColor(Color.rgb(57, 50, 70)); setPadding(dp(this@MainActivity, 18), dp(this@MainActivity, 12), dp(this@MainActivity, 18), dp(this@MainActivity, 12))
        }
        AlertDialog.Builder(this).setTitle("宠物日记").setView(ScrollView(this).apply { addView(text) })
            .setNeutralButton("清空") { _, _ -> JournalStore.clear(this) }
            .setPositiveButton("关闭", null).show()
    }
}
