package com.qi.petlife

import java.util.Calendar
import kotlin.random.Random

enum class PetEvent { PERIODIC, TAP, DOUBLE_TAP, LONG_PRESS, DRAG, FEED, PET, WAKE, CHARGING, LOW_BATTERY, FULL_BATTERY, SLEEP, MULTI_PET }

data class DialogueContext(
    val hour: Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY),
    val battery: Int = 100,
    val charging: Boolean = false,
    val companionDays: Int = 1,
    val ownerName: String = "主人"
)

object DialogueEngine {
    fun create(event: PetEvent, slot: PetSlot, ctx: DialogueContext): String {
        val custom = slot.customLines.split('\n', '|', '；').map { it.trim() }.filter { it.isNotEmpty() }
        if (event == PetEvent.PERIODIC && custom.isNotEmpty() && Random.nextInt(100) < 28) return custom.random()

        val p = slot.personality
        val name = slot.name.ifBlank { "小家伙" }
        val owner = ctx.ownerName.ifBlank { "主人" }

        if (event == PetEvent.LOW_BATTERY || ctx.battery <= 15) return listOf(
            "手机快没电啦，我也要趴下了。", "只剩 ${ctx.battery}% 了，快去充电吧。", "电量告急！$owner，救救我。"
        ).random()
        if (event == PetEvent.FULL_BATTERY || (ctx.charging && ctx.battery >= 98)) return listOf(
            "满血复活！今天也精神满满。", "充满啦，我又有力气陪你了。", "能量 100%，出发！"
        ).random()
        if (event == PetEvent.CHARGING || ctx.charging) return listOf(
            "开饭啦，正在充电！", "咕嘟咕嘟补充能量中。", "正在充电，我也暖乎乎的。"
        ).random()

        return when (event) {
            PetEvent.TAP -> personalityLine(p,
                cheerful = listOf("嘿嘿，你碰到我啦！", "再摸一下嘛。", "我在这里呀！"),
                gentle = listOf("嗯，我感觉到你了。", "今天也陪着你。", "轻轻的，好舒服。"),
                tsundere = listOf("才、才不是在等你点我。", "突然碰我做什么……", "哼，只允许一下。"),
                silly = listOf("咦？刚才是谁戳我？", "脑袋晃了一下。", "我是不是按错按钮了？"),
                clingy = listOf("终于理我啦！", "不要停，再陪我一会儿。", "$owner，我一直在等你。"),
                cool = listOf("我知道了。", "嗯。", "别一直戳。"),
                robot = listOf("触摸信号已接收。", "互动模块运行正常。", "检测到友好接触。")
            )
            PetEvent.DOUBLE_TAP -> listOf("送你一颗小爱心！", "啵！今天也喜欢你。", "双击成功，亲密度上升。", "爱心发射——").random()
            PetEvent.LONG_PRESS -> listOf("长按我，可以打开设置哦。", "想给我换衣服吗？", "设置菜单在等你。", "要不要给我换个新造型？").random()
            PetEvent.DRAG -> personalityLine(p,
                cheerful = listOf("我们要搬家吗？", "飞起来啦！", "带我去一个好位置吧。"),
                gentle = listOf("慢一点，我会跟着你的。", "想把我放在哪里呢？"),
                tsundere = listOf("喂，不要随便搬我！", "我自己会走啦。"),
                silly = listOf("地面怎么跑起来了？", "我在空中游泳！"),
                clingy = listOf("你要带我一起走吗？", "抓紧我，不要放开。"),
                cool = listOf("位置已改变。", "随你。"),
                robot = listOf("坐标重新校准。", "移动指令执行中。")
            )
            PetEvent.FEED -> listOf("好吃！心情变好了。", "谢谢投喂，我吃饱啦。", "再来一口就更好了。", "能量补充完成！").random()
            PetEvent.PET -> listOf("好舒服……", "再摸摸头嘛。", "今天最喜欢你了。", "呼噜呼噜。", "心情正在变好。").random()
            PetEvent.WAKE -> when {
                ctx.hour < 7 -> listOf("这么早就醒啦？", "天还没亮，我陪你一会儿。", "早起的人会遇到小幸运。 ").random()
                ctx.hour < 11 -> listOf("早上好，$owner！", "新的一天开始啦。", "早安，我已经醒啦。 ").random()
                ctx.hour < 18 -> listOf("欢迎回来！", "我刚刚还在想你。", "今天过得怎么样？").random()
                ctx.hour < 23 -> listOf("晚上好，辛苦一天啦。", "终于回来啦。", "今晚也一起待着吧。").random()
                else -> listOf("已经很晚啦，要记得休息。", "夜深了，我都开始犯困了。", "再陪你一会儿就睡吧。").random()
            }
            PetEvent.SLEEP -> listOf("晚安，我先睡一小会儿。", "Zzz……不要偷偷戳我。", "困困，今天也辛苦了。", "我去梦里找小鱼干啦。").random()
            PetEvent.MULTI_PET -> listOf("我们一起玩吧！", "$name，快看那边！", "今天桌面上好热闹。", "要不要一起睡午觉？", "我找到新朋友啦。").random()
            PetEvent.PERIODIC -> periodic(slot, ctx)
            else -> "我在这里。"
        }
    }

    private fun periodic(slot: PetSlot, ctx: DialogueContext): String {
        if (slot.energy < 20) return listOf("眼睛快睁不开了……", "我想趴一会儿。", "今天的能量快用完啦。 ").random()
        if (slot.hunger > 82) return listOf("肚子咕咕叫了。", "是不是到吃饭时间啦？", "我闻到零食的味道了。 ").random()
        if (slot.mood < 25) return listOf("今天有一点点不开心。", "陪我安静待一会儿吧。", "摸摸头，也许会好一点。 ").random()

        val timeLines = when (ctx.hour) {
            in 5..8 -> listOf("早晨的空气一定很舒服。", "早呀，今天也要有精神。", "我已经伸完懒腰啦。")
            in 9..11 -> listOf("今天有什么计划吗？", "我会安静陪你工作。", "记得喝点水。")
            in 12..13 -> listOf("到饭点啦，你吃东西了吗？", "午饭时间，我也饿了。", "吃饱以后会更有精神。")
            in 14..17 -> listOf("下午有一点犯困。", "要不要休息几分钟？", "我刚才数了好多朵云。")
            in 18..21 -> listOf("晚上好，今天辛苦啦。", "现在适合慢慢放松。", "我一直在桌面上等你。")
            else -> listOf("已经很晚了，别忘记休息。", "夜里安安静静的。", "再玩一会儿就睡觉吧。")
        }
        val personalityExtras = when (slot.personality) {
            0 -> listOf("我要开始今天的冒险啦！", "来比赛谁先笑出来。", "我有用不完的精神！")
            1 -> listOf("不用着急，慢慢来就好。", "今天也要温柔对待自己。", "我会一直安静陪着你。")
            2 -> listOf("我才没有一直看着你。", "别误会，我只是路过。", "哼，今天就勉强陪你。")
            3 -> listOf("我刚才发呆到哪里了？", "脑袋里好像住着一团云。", "咦，我本来想说什么来着？")
            4 -> listOf("不要把我一个人放太久嘛。", "$ctx.ownerName，我想靠近一点。", "只要你在，我就很开心。")
            5 -> listOf("躺平也是一种生活方式。", "今天适合慢慢晃。", "能坐着就不站着。")
            6 -> listOf("我刚才偷偷跑到屏幕边缘啦。", "猜猜我下一秒会做什么。", "要不要一起捣个小乱？")
            7 -> listOf("你已经做得很好了。", "不开心的时候也可以停下来。", "今天也值得被好好对待。")
            8 -> listOf("安静一点也不错。", "我在观察。", "不说话的时候，我也在陪你。")
            9 -> listOf("再不理我，我就偷偷藏起来。", "嘿嘿，我想到一个坏主意。", "小心，我要突然跳一下。")
            10 -> listOf("今日提醒：记得喝水。", "桌面秩序一切正常。", "需要我陪你休息吗？")
            else -> listOf("系统状态良好。", "陪伴程序持续运行中。", "今日互动数据等待更新。")
        }
        return (timeLines + personalityExtras).random()
    }

    private fun personalityLine(
        p: Int,
        cheerful: List<String>, gentle: List<String>, tsundere: List<String>, silly: List<String>,
        clingy: List<String>, cool: List<String>, robot: List<String>
    ): String = when (p) {
        0, 6 -> cheerful.random()
        1, 7, 10 -> gentle.random()
        2, 9 -> tsundere.random()
        3, 5 -> silly.random()
        4 -> clingy.random()
        8 -> cool.random()
        11 -> robot.random()
        else -> cheerful.random()
    }
}
