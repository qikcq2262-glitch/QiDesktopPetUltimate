package com.qi.petlife

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object PetPrefs {
    private const val PREF = "qi_pet_ultimate"
    private const val KEY = "config_json"

    fun load(context: Context): AppConfig {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null)
        if (raw.isNullOrBlank()) return AppConfig().normalize()
        return runCatching { fromJson(JSONObject(raw)) }.getOrElse { AppConfig() }.normalize()
    }

    fun save(context: Context, config: AppConfig) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, toJson(config.normalize()).toString()).apply()
    }

    fun exportText(config: AppConfig): String = toJson(config.normalize()).toString(2)
    fun importText(text: String): AppConfig = fromJson(JSONObject(text)).normalize()

    private fun toJson(config: AppConfig): JSONObject = JSONObject().apply {
        put("version", 4)
        put("activeCount", config.activeCount)
        put("selectedSlot", config.selectedSlot)
        put("speechEnabled", config.speechEnabled)
        put("speechLevel", config.speechLevel)
        put("ttsEnabled", config.ttsEnabled)
        put("ttsRate", config.ttsRate)
        put("ownerName", config.ownerName)
        put("needsEnabled", config.needsEnabled)
        put("multiPetTalk", config.multiPetTalk)
        put("journalEnabled", config.journalEnabled)
        put("autoStart", config.autoStart)
        put("pauseOnLock", config.pauseOnLock)
        put("lowPowerMode", config.lowPowerMode)
        put("quietStart", config.quietStart)
        put("quietEnd", config.quietEnd)
        put("slots", JSONArray().apply { config.slots.forEach { put(slotToJson(it)) } })
    }

    private fun slotToJson(s: PetSlot): JSONObject = JSONObject().apply {
        put("enabled", s.enabled); put("name", s.name); put("petId", s.petId); put("customUri", s.customUri)
        put("sizeDp", s.sizeDp); put("opacity", s.opacity); put("useCustomColors", s.useCustomColors)
        put("primaryColor", s.primaryColor); put("secondaryColor", s.secondaryColor); put("accentColor", s.accentColor)
        put("expression", s.expression); put("personality", s.personality); put("autoWalk", s.autoWalk)
        put("bounceEdges", s.bounceEdges); put("speed", s.speed); put("activity", s.activity)
        put("shadow", s.shadow); put("outline", s.outline); put("mirror", s.mirror); put("bubbleStyle", s.bubbleStyle)
        put("x", s.x); put("y", s.y); put("mood", s.mood); put("hunger", s.hunger)
        put("energy", s.energy); put("affection", s.affection); put("cleanliness", s.cleanliness)
        put("customLines", s.customLines)
    }

    private fun fromJson(o: JSONObject): AppConfig {
        val cfg = AppConfig(
            activeCount = o.optInt("activeCount", 1),
            selectedSlot = o.optInt("selectedSlot", 0),
            speechEnabled = o.optBoolean("speechEnabled", true),
            speechLevel = o.optInt("speechLevel", 2),
            ttsEnabled = o.optBoolean("ttsEnabled", false),
            ttsRate = o.optInt("ttsRate", 95),
            ownerName = o.optString("ownerName", "主人"),
            needsEnabled = o.optBoolean("needsEnabled", true),
            multiPetTalk = o.optBoolean("multiPetTalk", true),
            journalEnabled = o.optBoolean("journalEnabled", true),
            autoStart = o.optBoolean("autoStart", false),
            pauseOnLock = o.optBoolean("pauseOnLock", true),
            lowPowerMode = o.optBoolean("lowPowerMode", true),
            quietStart = o.optInt("quietStart", 23),
            quietEnd = o.optInt("quietEnd", 7),
            slots = mutableListOf()
        )
        val arr = o.optJSONArray("slots") ?: JSONArray()
        for (i in 0 until arr.length()) cfg.slots.add(slotFromJson(arr.optJSONObject(i) ?: JSONObject()))
        return cfg
    }

    private fun slotFromJson(o: JSONObject): PetSlot = PetSlot(
        enabled = o.optBoolean("enabled", true),
        name = o.optString("name", "团团"),
        petId = o.optString("petId", "cat_milk"),
        customUri = o.optString("customUri", ""),
        sizeDp = o.optInt("sizeDp", 150).coerceIn(72, 300),
        opacity = o.optInt("opacity", 100).coerceIn(25, 100),
        useCustomColors = o.optBoolean("useCustomColors", false),
        primaryColor = o.optInt("primaryColor", 0xFFF9F6F2.toInt()),
        secondaryColor = o.optInt("secondaryColor", 0xFF3E3946.toInt()),
        accentColor = o.optInt("accentColor", 0xFFFF8EB1.toInt()),
        expression = o.optInt("expression", 0).coerceIn(0, PetText.expressions.lastIndex),
        personality = o.optInt("personality", 0).coerceIn(0, PetText.personalities.lastIndex),
        autoWalk = o.optBoolean("autoWalk", true),
        bounceEdges = o.optBoolean("bounceEdges", true),
        speed = o.optInt("speed", 42).coerceIn(1, 100),
        activity = o.optInt("activity", 55).coerceIn(0, 100),
        shadow = o.optBoolean("shadow", true),
        outline = o.optBoolean("outline", false),
        mirror = o.optBoolean("mirror", false),
        bubbleStyle = o.optInt("bubbleStyle", 0).coerceIn(0, PetText.bubbleStyles.lastIndex),
        x = o.optInt("x", 80), y = o.optInt("y", 800),
        mood = o.optInt("mood", 82).coerceIn(0, 100),
        hunger = o.optInt("hunger", 28).coerceIn(0, 100),
        energy = o.optInt("energy", 76).coerceIn(0, 100),
        affection = o.optInt("affection", 15).coerceIn(0, 9999),
        cleanliness = o.optInt("cleanliness", 90).coerceIn(0, 100),
        customLines = o.optString("customLines", "")
    )
}
