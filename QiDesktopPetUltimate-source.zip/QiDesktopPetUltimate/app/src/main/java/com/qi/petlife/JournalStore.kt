package com.qi.petlife

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object JournalStore {
    private const val PREF = "qi_pet_journal"
    private const val KEY = "events"
    private const val MAX = 120

    fun append(context: Context, petName: String, text: String) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrElse { JSONArray() }
        val out = JSONArray()
        out.put(JSONObject().put("time", System.currentTimeMillis()).put("pet", petName).put("text", text))
        for (i in 0 until minOf(arr.length(), MAX - 1)) out.put(arr.optJSONObject(i))
        prefs.edit().putString(KEY, out.toString()).apply()
    }

    fun recentText(context: Context, limit: Int = 40): String {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        if (arr.length() == 0) return "还没有日记。和宠物互动后，这里会记录它的小故事。"
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        return buildString {
            for (i in 0 until minOf(limit, arr.length())) {
                val o = arr.optJSONObject(i) ?: continue
                append(fmt.format(Date(o.optLong("time")))).append("  ")
                append(o.optString("pet")).append("：").append(o.optString("text")).append("\n\n")
            }
        }.trim()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
