package com.qi.petlife

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs

class PetOverlayView(
    context: Context,
    val slotIndex: Int,
    initialSlot: PetSlot,
    private val callback: Callback
) : FrameLayout(context) {

    interface Callback {
        fun onMove(slotIndex: Int, dx: Int, dy: Int, finished: Boolean)
        fun onTap(slotIndex: Int)
        fun onDoubleTap(slotIndex: Int)
        fun onLongPress(slotIndex: Int)
    }

    val petView = PetCanvasView(context)
    private val bubble = TextView(context)
    private val handler = Handler(Looper.getMainLooper())
    private var slot = initialSlot
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var longPressed = false
    private var lastTapAt = 0L
    private var typingRunnable: Runnable? = null
    private var hideRunnable: Runnable? = null
    private val longPressRunnable = Runnable {
        if (!moved) {
            longPressed = true
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            callback.onLongPress(slotIndex)
        }
    }

    init {
        clipChildren = false
        clipToPadding = false
        setPadding(dp(8), dp(2), dp(8), dp(2))
        bubble.gravity = Gravity.CENTER
        bubble.textSize = 13f
        bubble.setTextColor(Color.rgb(55, 48, 68))
        bubble.maxLines = 3
        bubble.visibility = View.GONE
        bubble.setPadding(dp(12), dp(8), dp(12), dp(8))
        addView(bubble, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        addView(petView, LayoutParams(dp(initialSlot.sizeDp), dp(initialSlot.sizeDp), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        update(initialSlot)
        isClickable = true
        setOnTouchListener { _, event -> handleTouch(event) }
    }

    fun update(newSlot: PetSlot) {
        slot = newSlot
        petView.slot = newSlot.copy()
        val petLp = petView.layoutParams as LayoutParams
        petLp.width = dp(newSlot.sizeDp)
        petLp.height = dp(newSlot.sizeDp)
        petLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        petView.layoutParams = petLp
        val bubbleLp = bubble.layoutParams as LayoutParams
        bubbleLp.topMargin = 0
        bubble.layoutParams = bubbleLp
        applyBubbleStyle(newSlot.bubbleStyle)
        requestLayout()
    }

    fun setPaused(paused: Boolean) {
        petView.animationEnabled = !paused
        if (paused) hideBubble()
    }

    fun action(name: String, expression: Int? = null, duration: Long = 1200L) {
        petView.action = name
        petView.forcedExpression = expression
        petView.invalidate()
        handler.postDelayed({
            petView.action = "idle"
            petView.forcedExpression = null
            petView.invalidate()
        }, duration)
    }

    fun showBubble(text: String, duration: Long = 4600L, typewriter: Boolean = true) {
        typingRunnable?.let(handler::removeCallbacks)
        hideRunnable?.let(handler::removeCallbacks)
        bubble.visibility = View.VISIBLE
        bubble.alpha = 0f
        bubble.animate().alpha(1f).translationY(0f).setDuration(180).start()
        if (!typewriter || text.length < 5) {
            bubble.text = text
        } else {
            bubble.text = ""
            var index = 0
            val r = object : Runnable {
                override fun run() {
                    if (index <= text.length) {
                        bubble.text = text.substring(0, index)
                        index++
                        handler.postDelayed(this, 38L)
                    }
                }
            }
            typingRunnable = r
            handler.post(r)
        }
        hideRunnable = Runnable { hideBubble() }.also { handler.postDelayed(it, duration) }
    }

    fun hideBubble() {
        typingRunnable?.let(handler::removeCallbacks)
        hideRunnable?.let(handler::removeCallbacks)
        bubble.animate().alpha(0f).setDuration(180).withEndAction { bubble.visibility = View.GONE }.start()
    }

    private fun handleTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; moved = false; longPressed = false
                handler.postDelayed(longPressRunnable, 560L)
                petView.action = "happy"
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - downX).toInt()
                val dy = (e.rawY - downY).toInt()
                if (abs(dx) > dp(5) || abs(dy) > dp(5)) moved = true
                if (moved) {
                    handler.removeCallbacks(longPressRunnable)
                    callback.onMove(slotIndex, dx, dy, false)
                    downX = e.rawX; downY = e.rawY
                    petView.action = "walk"
                    petView.facingRight = dx >= 0
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                petView.action = "idle"
                if (moved) callback.onMove(slotIndex, 0, 0, true)
                else if (!longPressed && e.actionMasked == MotionEvent.ACTION_UP) {
                    val now = System.currentTimeMillis()
                    if (now - lastTapAt < 330L) {
                        lastTapAt = 0L
                        callback.onDoubleTap(slotIndex)
                    } else {
                        lastTapAt = now
                        handler.postDelayed({
                            if (lastTapAt == now) {
                                callback.onTap(slotIndex)
                                lastTapAt = 0L
                            }
                        }, 340L)
                    }
                }
                return true
            }
        }
        return false
    }

    private fun applyBubbleStyle(style: Int) {
        when (style) {
            0 -> {
                bubble.setTextColor(Color.rgb(62, 52, 76))
                bubble.background = shape(Color.rgb(255, 250, 246), 20f, Color.rgb(228, 213, 236), 1)
            }
            1 -> {
                bubble.setTextColor(Color.BLACK)
                bubble.background = shape(Color.WHITE, 7f, Color.BLACK, 2)
            }
            2 -> {
                bubble.setTextColor(Color.WHITE)
                bubble.background = shape(Color.argb(195, 40, 42, 55), 18f, Color.argb(100, 255, 255, 255), 1)
            }
            3 -> {
                bubble.setTextColor(Color.rgb(42, 45, 55))
                bubble.background = shape(Color.rgb(224, 246, 255), 2f, Color.rgb(52, 80, 100), 2)
            }
            else -> {
                bubble.setTextColor(Color.WHITE)
                bubble.background = shape(Color.argb(155, 20, 20, 28), 14f, Color.TRANSPARENT, 0)
            }
        }
    }

    private fun shape(color: Int, radius: Float, strokeColor: Int, strokeWidth: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius.toInt()).toFloat()
        if (strokeWidth > 0) setStroke(dp(strokeWidth), strokeColor)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + .5f).toInt()
}
