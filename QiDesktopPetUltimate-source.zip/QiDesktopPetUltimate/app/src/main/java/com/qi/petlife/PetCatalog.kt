package com.qi.petlife

import android.graphics.Color

object PetCatalog {
    private fun c(hex: String): Int = Color.parseColor(hex)

    val all: List<PetDefinition> = buildList {
        fun addPet(id:String, name:String, category:String, family:PetFamily, p:String, s:String, a:String, accessory:Accessory=Accessory.NONE, variant:Int=0, desc:String="") {
            add(PetDefinition(id, name, category, family, c(p), c(s), c(a), accessory, variant, desc))
        }

        // 猫咪家族（16）
        addPet("cat_milk","奶盖牛奶猫","猫咪",PetFamily.CAT,"#FFF9F4","#3D3946","#FF91B5",Accessory.BELL,0)
        addPet("cat_orange","橘子汽水猫","猫咪",PetFamily.CAT,"#F6A14B","#9B542A","#FFD267",Accessory.SCARF,1)
        addPet("cat_black","黑曜星星猫","猫咪",PetFamily.CAT,"#35313F","#16141C","#9DD8FF",Accessory.STAR,2)
        addPet("cat_white","云朵白猫","猫咪",PetFamily.CAT,"#FFFEFC","#6A6375","#FFB7CB",Accessory.BOW,3)
        addPet("cat_ragdoll","布偶奶霜猫","猫咪",PetFamily.CAT,"#F5EAE0","#927B78","#89B7FF",Accessory.RIBBON,4)
        addPet("cat_silver","银渐层团子","猫咪",PetFamily.CAT,"#D8DCE5","#575B69","#B9A5FF",Accessory.CROWN,5)
        addPet("cat_calico","三花糯米猫","猫咪",PetFamily.CAT,"#FFF4E8","#5A4D47","#FF9E7E",Accessory.FLOWER,6)
        addPet("cat_british","英短蓝莓猫","猫咪",PetFamily.CAT,"#8793A8","#424A59","#FFD36B",Accessory.GLASSES,7)
        addPet("cat_siamese","暹罗咖啡猫","猫咪",PetFamily.CAT,"#EBD8C0","#5C4947","#8FD8FF",Accessory.GEM,8)
        addPet("cat_pink","草莓梦境猫","猫咪",PetFamily.CAT,"#F9C4D4","#8F5B70","#FFF0A6",Accessory.HEART,9)
        addPet("cat_mint","薄荷小猫","猫咪",PetFamily.CAT,"#AEE7D5","#37675E","#FFF2A3",Accessory.LEAF,10)
        addPet("cat_lavender","薰衣草猫","猫咪",PetFamily.CAT,"#C8B5F6","#574B78","#FFB6D2",Accessory.FLOWER,11)
        addPet("cat_sun","太阳花猫","猫咪",PetFamily.CAT,"#FFD878","#815A2F","#FF8FA0",Accessory.FLOWER,12)
        addPet("cat_moon","月光睡睡猫","猫咪",PetFamily.CAT,"#CDD8F5","#45516D","#FFF0A8",Accessory.HALO,13)
        addPet("cat_pixel","像素机灵猫","猫咪",PetFamily.CAT,"#89D3F5","#294C65","#FF85C8",Accessory.HEADPHONES,14)
        addPet("cat_royal","皇家奶茶猫","猫咪",PetFamily.CAT,"#DDBA91","#624A3D","#F9D55C",Accessory.CROWN,15)

        // 狗狗家族（14）
        addPet("dog_corgi","柯基小短腿","狗狗",PetFamily.DOG,"#ECA057","#8A4C2D","#FFF1C2",Accessory.BELL,0)
        addPet("dog_shiba","柴犬团团","狗狗",PetFamily.DOG,"#D98545","#70402B","#FFF1D3",Accessory.SCARF,1)
        addPet("dog_samoyed","萨摩耶雪球","狗狗",PetFamily.DOG,"#FFFDF8","#5A5B66","#BCE6FF",Accessory.RIBBON,2)
        addPet("dog_husky","哈士奇冰冰","狗狗",PetFamily.WOLF,"#CAD3DF","#3E4653","#8FD4FF",Accessory.HEADPHONES,3)
        addPet("dog_poodle","泰迪布丁","狗狗",PetFamily.DOG,"#C99165","#664432","#FFB6C9",Accessory.BOW,4)
        addPet("dog_golden","金毛暖暖","狗狗",PetFamily.DOG,"#E6B96A","#8B6130","#FFF0A8",Accessory.LEAF,5)
        addPet("dog_beagle","比格豆豆","狗狗",PetFamily.DOG,"#E7C49D","#654C3E","#FF9C86",Accessory.BACKPACK,6)
        addPet("dog_maltese","马尔济斯棉花","狗狗",PetFamily.DOG,"#FFFEFB","#68616C","#FFB9D0",Accessory.FLOWER,7)
        addPet("dog_border","边牧聪聪","狗狗",PetFamily.DOG,"#F8F8F5","#292B31","#77C7FF",Accessory.GLASSES,8)
        addPet("dog_dachshund","腊肠可可","狗狗",PetFamily.DOG,"#9F633D","#4A3127","#FFD06D",Accessory.CAP,9)
        addPet("dog_pug","巴哥憨憨","狗狗",PetFamily.DOG,"#C8A986","#4E4140","#FFAE91",Accessory.NONE,10)
        addPet("dog_pom","博美泡芙","狗狗",PetFamily.DOG,"#F1C890","#865E3C","#FFB4D0",Accessory.CROWN,11)
        addPet("dog_blue","蓝莓机械犬","狗狗",PetFamily.ROBOT,"#80C7F4","#304B66","#B6FFEB",Accessory.HEADPHONES,12)
        addPet("dog_fox","赤狐犬团","狗狗",PetFamily.FOX,"#E17C45","#60352D","#FFF0CE",Accessory.SCARF,13)

        // 兔熊鼠与森林动物（20）
        addPet("rabbit_white","白桃垂耳兔","森林",PetFamily.RABBIT,"#FFF8F8","#675D6D","#FFAAC4",Accessory.BOW,0)
        addPet("rabbit_pink","草莓奶兔","森林",PetFamily.RABBIT,"#F7C2D2","#7C5466","#FFF0A0",Accessory.FLOWER,1)
        addPet("rabbit_mint","薄荷长耳兔","森林",PetFamily.RABBIT,"#B8E8D9","#44675E","#FFB4CE",Accessory.LEAF,2)
        addPet("rabbit_moon","月光睡兔","森林",PetFamily.RABBIT,"#CFD9F4","#4A526D","#FFF1A6",Accessory.HALO,3)
        addPet("bear_brown","蜂蜜小熊","森林",PetFamily.BEAR,"#B98159","#563B31","#FFD96D",Accessory.SCARF,0)
        addPet("bear_polar","极地奶油熊","森林",PetFamily.BEAR,"#FFFEF8","#606775","#AEE2FF",Accessory.RIBBON,1)
        addPet("bear_panda","竹叶熊猫","森林",PetFamily.BEAR,"#F7F7F2","#25262C","#83D08B",Accessory.LEAF,2)
        addPet("bear_strawberry","草莓软糖熊","森林",PetFamily.BEAR,"#F6AFC3","#7D5262","#FFF1A0",Accessory.HEART,3)
        addPet("hamster_gold","金丝仓鼠","森林",PetFamily.RODENT,"#E5AF65","#765032","#FFD1A8",Accessory.NONE,0)
        addPet("hamster_milk","奶茶仓鼠","森林",PetFamily.RODENT,"#D9BA9B","#665045","#FFB7C9",Accessory.BELL,1)
        addPet("squirrel_acorn","橡果松鼠","森林",PetFamily.RODENT,"#B87549","#5A3627","#F5CE72",Accessory.LEAF,2)
        addPet("fox_red","红叶小狐狸","森林",PetFamily.FOX,"#E47C46","#63372D","#FFF0D5",Accessory.LEAF,0)
        addPet("fox_snow","雪原银狐","森林",PetFamily.FOX,"#E4EAF3","#606A7D","#B8E8FF",Accessory.SCARF,1)
        addPet("fox_pink","樱花梦狐","森林",PetFamily.FOX,"#F3B5CB","#7F5269","#FFF2A4",Accessory.FLOWER,2)
        addPet("deer_fawn","小鹿斑比","森林",PetFamily.DEER,"#C69364","#5C4134","#FFE18A",Accessory.FLOWER,0)
        addPet("deer_star","星角小鹿","森林",PetFamily.DEER,"#BCA8E8","#51466D","#FFF2A2",Accessory.STAR,1)
        addPet("sheep_cloud","云朵绵羊","森林",PetFamily.SHEEP,"#FFFDF6","#6D625D","#B7DFFF",Accessory.BOW,0)
        addPet("alpaca_milk","奶盖羊驼","森林",PetFamily.ALPACA,"#F3E4CF","#6D5949","#FFAFC8",Accessory.SCARF,0)
        addPet("wolf_moon","月夜小狼","森林",PetFamily.WOLF,"#77849C","#303746","#BFD7FF",Accessory.HALO,0)
        addPet("raccoon_cookie","饼干浣熊","森林",PetFamily.RODENT,"#9A8C83","#3E3939","#FFD07A",Accessory.BACKPACK,4)

        // 鸟类与海洋（18）
        addPet("chick_lemon","柠檬小鸡","飞鸟海洋",PetFamily.CHICK,"#FFD85C","#795926","#FF9B55",Accessory.NONE,0)
        addPet("chick_pink","樱花小鸡","飞鸟海洋",PetFamily.CHICK,"#F6B9CA","#7C5362","#FFF2A0",Accessory.BOW,1)
        addPet("bird_blue","蓝莓啾啾","飞鸟海洋",PetFamily.BIRD,"#83C8EE","#31546A","#FFF0A5",Accessory.STAR,0)
        addPet("bird_parrot","彩虹鹦鹉","飞鸟海洋",PetFamily.BIRD,"#78D9A6","#325F4E","#FF9D6C",Accessory.FLOWER,1)
        addPet("owl_cocoa","可可猫头鹰","飞鸟海洋",PetFamily.OWL,"#A87B60","#4D392F","#FFD77B",Accessory.GLASSES,0)
        addPet("owl_snow","雪团猫头鹰","飞鸟海洋",PetFamily.OWL,"#F6F8FB","#646B78","#AEDFFF",Accessory.CROWN,1)
        addPet("penguin_ice","冰糖企鹅","飞鸟海洋",PetFamily.PENGUIN,"#303746","#11151C","#8DDAFF",Accessory.SCARF,0)
        addPet("penguin_pink","粉雪企鹅","飞鸟海洋",PetFamily.PENGUIN,"#4B4D60","#242531","#FFB4D4",Accessory.BOW,1)
        addPet("seal_mochi","糯米小海豹","飞鸟海洋",PetFamily.SEAL,"#E5EAF1","#59616E","#B5E5FF",Accessory.NONE,0)
        addPet("seal_spot","芝麻斑海豹","飞鸟海洋",PetFamily.SEAL,"#C9D0D9","#525966","#FFB5C7",Accessory.HEART,1)
        addPet("otter_shell","贝壳小水獭","飞鸟海洋",PetFamily.OTTER,"#A87555","#4F372B","#9FE1E8",Accessory.GEM,0)
        addPet("whale_blue","蓝海小鲸鱼","飞鸟海洋",PetFamily.WHALE,"#76BDE8","#31536D","#C8F0FF",Accessory.STAR,0)
        addPet("whale_pink","粉霞小鲸鱼","飞鸟海洋",PetFamily.WHALE,"#E9AFC4","#744F61","#FFF1A4",Accessory.HEART,1)
        addPet("octopus_grape","葡萄章鱼","飞鸟海洋",PetFamily.OCTOPUS,"#B99AEB","#554674","#FFB8D0",Accessory.CROWN,0)
        addPet("octopus_mint","薄荷章鱼","飞鸟海洋",PetFamily.OCTOPUS,"#8EDBCB","#35655D","#FFF09A",Accessory.BOW,1)
        addPet("turtle_matcha","抹茶小海龟","飞鸟海洋",PetFamily.TURTLE,"#83C78E","#3A6544","#F5DF75",Accessory.LEAF,0)
        addPet("frog_lotus","荷叶青蛙","飞鸟海洋",PetFamily.FROG,"#82D184","#35643A","#FFB0C7",Accessory.LEAF,0)
        addPet("frog_rain","雨滴蓝蛙","飞鸟海洋",PetFamily.FROG,"#77C8D8","#315D69","#FFF1A2",Accessory.CAP,1)

        // 幻想与机械（28）
        addPet("dino_mint","薄荷小恐龙","幻想",PetFamily.DINO,"#83D8BE","#356357","#FFF0A0",Accessory.BACKPACK,0)
        addPet("dino_pink","草莓小恐龙","幻想",PetFamily.DINO,"#F3AFC4","#7A4D60","#FFF1A0",Accessory.BOW,1)
        addPet("dino_blue","冰川小恐龙","幻想",PetFamily.DINO,"#89C8F0","#355A75","#D6F4FF",Accessory.SCARF,2)
        addPet("dragon_fire","火苗幼龙","幻想",PetFamily.DRAGON,"#E98158","#643B34","#FFD46A",Accessory.GEM,0)
        addPet("dragon_ice","冰晶幼龙","幻想",PetFamily.DRAGON,"#9BD2F6","#3D5870","#E7F9FF",Accessory.GEM,1)
        addPet("dragon_dream","梦境幼龙","幻想",PetFamily.DRAGON,"#BFA9EE","#544772","#FFB6D4",Accessory.STAR,2)
        addPet("unicorn_milk","奶油独角兽","幻想",PetFamily.UNICORN,"#FFF9F3","#7A6574","#E0B4FF",Accessory.CROWN,0)
        addPet("unicorn_rainbow","彩虹独角兽","幻想",PetFamily.UNICORN,"#F6EAFB","#715B7D","#FFB3D0",Accessory.STAR,1)
        addPet("slime_mint","薄荷史莱姆","幻想",PetFamily.SLIME,"#78D9C1","#30655B","#FFF09C",Accessory.LEAF,0)
        addPet("slime_grape","葡萄史莱姆","幻想",PetFamily.SLIME,"#A985E0","#4D3F6B","#FFB7D1",Accessory.CROWN,1)
        addPet("slime_honey","蜂蜜史莱姆","幻想",PetFamily.SLIME,"#F5C860","#7B5B28","#FFF2B5",Accessory.BELL,2)
        addPet("ghost_milk","牛奶小幽灵","幻想",PetFamily.GHOST,"#F8F7FF","#555267","#B8A9FF",Accessory.HALO,0)
        addPet("ghost_pink","害羞粉幽灵","幻想",PetFamily.GHOST,"#F3C1D2","#755366","#FFF2A4",Accessory.BOW,1)
        addPet("spirit_cloud","云朵精灵","幻想",PetFamily.CLOUD,"#FFFFFF","#667087","#AEE4FF",Accessory.HALO,0)
        addPet("spirit_leaf","叶子精灵","幻想",PetFamily.SPIRIT,"#A7E0B0","#41634A","#FFF0A0",Accessory.LEAF,1)
        addPet("spirit_flower","花瓣精灵","幻想",PetFamily.SPIRIT,"#F3B9CD","#765365","#FFF3A5",Accessory.FLOWER,2)
        addPet("star_pudding","布丁星星","幻想",PetFamily.STAR,"#FFD978","#765824","#FF9DBD",Accessory.CROWN,0)
        addPet("star_moon","月亮星灵","幻想",PetFamily.STAR,"#C8D7F5","#4B5673","#FFF0A3",Accessory.HALO,1)
        addPet("robot_mini","迷你助手Q","机械",PetFamily.ROBOT,"#81C4F3","#294B64","#8CFFD5",Accessory.HEADPHONES,0)
        addPet("robot_pink","粉糖机器人","机械",PetFamily.ROBOT,"#F0AAC3","#69495A","#FFF09C",Accessory.BOW,1)
        addPet("robot_space","宇航机器人","机械",PetFamily.ROBOT,"#E8EDF5","#3F4A5C","#86D8FF",Accessory.CAP,2)
        addPet("alien_mint","薄荷外星团","机械",PetFamily.ALIEN,"#8CDBBE","#365E54","#D9FF9D",Accessory.HEADPHONES,0)
        addPet("alien_grape","葡萄外星团","机械",PetFamily.ALIEN,"#B29AE8","#4E4268","#FFB6D1",Accessory.STAR,1)
        addPet("cloud_rain","下雨云团","幻想",PetFamily.CLOUD,"#B8C8DE","#526078","#7DD8FF",Accessory.NONE,1)
        addPet("cloud_sunset","晚霞云团","幻想",PetFamily.CLOUD,"#F4B6B1","#79566A","#FFD87A",Accessory.HEART,2)
        addPet("spirit_fire","小火苗精灵","幻想",PetFamily.SPIRIT,"#FF9B5D","#6D3F32","#FFD66A",Accessory.GEM,3)
        addPet("spirit_water","水滴精灵","幻想",PetFamily.SPIRIT,"#75CDED","#315D75","#C8F5FF",Accessory.GEM,4)
        addPet("spirit_night","夜光精灵","幻想",PetFamily.SPIRIT,"#5B5D8C","#25273F","#B6A5FF",Accessory.STAR,5)

        // 自定义入口
        addPet("custom","我的自定义宠物","自定义",PetFamily.CAT,"#FFFFFF","#444444","#FF99BB",Accessory.NONE,0,"支持透明 PNG、JPG、WebP、GIF 与动态 WebP")
    }

    val byId: Map<String, PetDefinition> = all.associateBy { it.id }
    val categories: List<String> = listOf("全部") + all.map { it.category }.distinct()

    fun get(id: String): PetDefinition = byId[id] ?: all.first()
    fun names(category: String = "全部"): List<String> = filtered(category).map { it.name }
    fun filtered(category: String): List<PetDefinition> = if (category == "全部") all else all.filter { it.category == category }
}
