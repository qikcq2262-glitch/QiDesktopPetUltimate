package com.qi.petlife

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.TextView

fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density + .5f).toInt()

fun rounded(fill: Int, radiusDp: Int, stroke: Int = Color.TRANSPARENT, strokeWidthDp: Int = 0, context: Context? = null): GradientDrawable = GradientDrawable().apply {
    setColor(fill)
    cornerRadius = if (context == null) radiusDp.toFloat() else dp(context, radiusDp).toFloat()
    if (strokeWidthDp > 0) setStroke(if (context == null) strokeWidthDp else dp(context, strokeWidthDp), stroke)
}

fun View.padDp(context: Context, horizontal: Int, vertical: Int) {
    setPadding(dp(context, horizontal), dp(context, vertical), dp(context, horizontal), dp(context, vertical))
}

fun TextView.titleStyle(size: Float = 20f) {
    textSize = size
    setTextColor(Color.rgb(48, 42, 62))
    typeface = android.graphics.Typeface.DEFAULT_BOLD
}
