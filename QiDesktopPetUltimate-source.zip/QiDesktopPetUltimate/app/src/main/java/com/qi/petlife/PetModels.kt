package com.qi.petlife

import android.graphics.Color

enum class PetFamily {
    CAT, DOG, RABBIT, BEAR, RODENT, FOX, WOLF, DEER, SHEEP, ALPACA,
    BIRD, PENGUIN, CHICK, OWL, FROG, TURTLE, SEAL, OTTER, WHALE, OCTOPUS,
    DINO, DRAGON, UNICORN, SLIME, GHOST, SPIRIT, ROBOT, ALIEN, CLOUD, STAR
}

enum class Accessory {
    NONE, BELL, BOW, RIBBON, FLOWER, LEAF, CROWN, SCARF, GLASSES, HEART,
    STAR, CAP, HEADPHONES, HALO, BACKPACK, GEM
}

data class PetDefinition(
    val id: String,
    val name: String,
    val category: String,
    val family: PetFamily,
    val primary: Int,
    val secondary: Int,
    val accent: Int,
    val accessory: Accessory = Accessory.NONE,
    val variant: Int = 0,
    val description: String = ""
)

data class PetSlot(
    var enabled: Boolean = true,
    var name: String = "团团",
    var petId: String = "cat_milk",
    var customUri: String = "",
    var sizeDp: Int = 150,
    var opacity: Int = 100,
    var useCustomColors: Boolean = false,
    var primaryColor: Int = Color.rgb(249, 246, 242),
    var secondaryColor: Int = Color.rgb(62, 57, 70),
    var accentColor: Int = Color.rgb(255, 142, 177),
    var expression: Int = 0,
    var personality: Int = 0,
    var autoWalk: Boolean = true,
    var bounceEdges: Boolean = true,
    var speed: Int = 42,
    var activity: Int = 55,
    var shadow: Boolean = true,
    var outline: Boolean = false,
    var mirror: Boolean = false,
    var bubbleStyle: Int = 0,
    var x: Int = 80,
    var y: Int = 800,
    var mood: Int = 82,
    var hunger: Int = 28,
    var energy: Int = 76,
    var affection: Int = 15,
    var cleanliness: Int = 90,
    var customLines: String = ""
)

data class AppConfig(
    var activeCount: Int = 1,
    var selectedSlot: Int = 0,
    var speechEnabled: Boolean = true,
    var speechLevel: Int = 2,
    var ttsEnabled: Boolean = false,
    var ttsRate: Int = 95,
    var ownerName: String = "主人",
    var needsEnabled: Boolean = true,
    var multiPetTalk: Boolean = true,
    var journalEnabled: Boolean = true,
    var autoStart: Boolean = false,
    var pauseOnLock: Boolean = true,
    var lowPowerMode: Boolean = true,
    var quietStart: Int = 23,
    var quietEnd: Int = 7,
    var slots: MutableList<PetSlot> = mutableListOf(
        PetSlot(name = "团团", petId = "cat_milk", x = 60, y = 820),
        PetSlot(name = "豆包", petId = "dog_corgi", x = 420, y = 850, enabled = false),
        PetSlot(name = "绵绵", petId = "spirit_cloud", x = 120, y = 420, enabled = false),
        PetSlot(name = "星仔", petId = "star_pudding", x = 520, y = 520, enabled = false)
    )
) {
    fun normalize(): AppConfig {
        while (slots.size < 4) slots.add(PetSlot(enabled = false, name = "宠物${slots.size + 1}"))
        if (slots.size > 4) slots = slots.take(4).toMutableList()
        activeCount = activeCount.coerceIn(1, 4)
        selectedSlot = selectedSlot.coerceIn(0, 3)
        slots.forEachIndexed { index, slot -> slot.enabled = index < activeCount }
        return this
    }
}

object PetText {
    val personalities = listOf("元气", "温柔", "傲娇", "呆萌", "黏人", "慵懒", "调皮", "治愈", "高冷", "小恶魔", "管家", "机械助手")
    val expressions = listOf("自然", "开心", "眨眼", "害羞", "困困", "生气", "惊讶", "爱心眼", "星星眼", "委屈", "大笑", "发呆")
    val bubbleStyles = listOf("奶油圆角", "漫画气泡", "玻璃字幕", "像素方框", "纯文字")
    val speechLevels = listOf("安静", "偶尔", "正常", "活跃", "话痨")
}
