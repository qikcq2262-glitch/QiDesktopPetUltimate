package com.qi.petlife

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val config = PetPrefs.load(context)
        if (!config.autoStart || !Settings.canDrawOverlays(context)) return
        val service = Intent(context, OverlayPetService::class.java).setAction(OverlayPetService.ACTION_REFRESH)
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service) else context.startService(service)
    }
}
