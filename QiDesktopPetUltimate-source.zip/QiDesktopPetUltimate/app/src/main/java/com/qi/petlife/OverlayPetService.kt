package com.qi.petlife

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import java.util.Locale
import kotlin.math.abs
import kotlin.random.Random

class OverlayPetService : Service(), PetOverlayView.Callback, TextToSpeech.OnInitListener {
    companion object {
        const val ACTION_REFRESH = "com.qi.petlife.REFRESH"
        const val ACTION_STOP = "com.qi.petlife.STOP"
        private const val CHANNEL = "qi_pet_overlay"
        private const val NOTIFY_ID = 9417
    }

    private data class Runtime(
        val slotIndex: Int,
        val view: PetOverlayView,
        val params: WindowManager.LayoutParams,
        var velocityX: Float,
        var lastSpeechAt: Long = 0L,
        var lastActionAt: Long = 0L,
        var nextSpeechDelay: Long = 45_000L,
        var dragSpoken: Boolean = false
    )

    private lateinit var wm: WindowManager
    private val runtimes = mutableListOf<Runtime>()
    private val handler = Handler(Looper.getMainLooper())
    private var config = AppConfig()
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var battery = 100
    private var charging = false
    private var screenOn = true
    private var tickCount = 0L

    private val loop = object : Runnable {
        override fun run() {
            updateWorld()
            val delay = if (config.lowPowerMode) 50L else 33L
            handler.postDelayed(this, delay)
        }
    }

    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_BATTERY_CHANGED -> {
                    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 100)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
                    val oldBattery = battery
                    val oldCharging = charging
                    battery = level * 100 / scale
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
                    charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
                    if (!oldCharging && charging) speakRandom(PetEvent.CHARGING)
                    if (oldBattery > 15 && battery <= 15) speakRandom(PetEvent.LOW_BATTERY)
                    if (oldBattery < 98 && battery >= 98 && charging) speakRandom(PetEvent.FULL_BATTERY)
                }
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    if (config.pauseOnLock) runtimes.forEach { it.view.setPaused(true) }
                }
                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    runtimes.forEach { it.view.setPaused(false) }
                    handler.postDelayed({ speakRandom(PetEvent.WAKE) }, 900L)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        config = PetPrefs.load(this)
        createChannel()
        startForeground(NOTIFY_ID, notification())
        registerSystemReceiver()
        tts = TextToSpeech(this, this)
        rebuildOverlays()
        handler.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            else -> {
                config = PetPrefs.load(this)
                rebuildOverlays()
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        unregisterReceiverSafe()
        runtimes.forEach { runCatching { wm.removeView(it.view) } }
        runtimes.clear()
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale.SIMPLIFIED_CHINESE
            tts?.setSpeechRate(config.ttsRate / 100f)
            tts?.setPitch(1.08f)
        }
    }

    private fun rebuildOverlays() {
        runtimes.forEach { runCatching { wm.removeView(it.view) } }
        runtimes.clear()
        if (!Settings.canDrawOverlays(this)) return
        config.normalize()
        config.slots.take(config.activeCount).forEachIndexed { index, slot ->
            if (!slot.enabled) return@forEachIndexed
            val view = PetOverlayView(this, index, slot.copy(), this)
            val viewWidth = dp(maxOf(220, slot.sizeDp + 92))
            val viewHeight = dp(slot.sizeDp + 96)
            val params = WindowManager.LayoutParams(
                viewWidth,
                viewHeight,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = slot.x
                y = slot.y
            }
            runCatching { wm.addView(view, params) }.onSuccess {
                val speed = (slot.speed.coerceIn(1, 100) / 18f + 0.7f) * if (index % 2 == 0) 1 else -1
                runtimes.add(Runtime(index, view, params, speed, System.currentTimeMillis(), System.currentTimeMillis(), speechDelay()))
            }
        }
        if (runtimes.isNotEmpty() && config.speechEnabled) {
            handler.postDelayed({ speak(runtimes.first(), DialogueEngine.create(PetEvent.WAKE, config.slots[runtimes.first().slotIndex], contextFor())) }, 1400L)
        }
    }

    private fun updateWorld() {
        if (!screenOn && config.pauseOnLock) return
        tickCount++
        val now = System.currentTimeMillis()
        val bounds = if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds else {
            @Suppress("DEPRECATION")
            android.graphics.Rect(0, 0, resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)
        }
        val dt = if (config.lowPowerMode) .05f else .033f

        runtimes.forEach { rt ->
            val slot = config.slots.getOrNull(rt.slotIndex) ?: return@forEach
            if (slot.autoWalk && slot.energy > 6) {
                val speedScale = (0.45f + slot.speed / 32f) * if (slot.energy < 25) .45f else 1f
                rt.params.x += (rt.velocityX * speedScale * dt * 12f).toInt()
                rt.view.petView.action = "walk"
                rt.view.petView.facingRight = rt.velocityX >= 0
                val minX = -dp(26)
                val maxX = bounds.width() - rt.params.width + dp(26)
                if (rt.params.x <= minX || rt.params.x >= maxX) {
                    if (slot.bounceEdges) rt.velocityX *= -1f
                    rt.params.x = rt.params.x.coerceIn(minX, maxX.coerceAtLeast(minX))
                    rt.view.action("happy", 1, 650L)
                }
                runCatching { wm.updateViewLayout(rt.view, rt.params) }
            } else if (rt.view.petView.action == "walk") rt.view.petView.action = "idle"

            val actionInterval = (14_000L - slot.activity * 90L).coerceAtLeast(3_800L)
            if (now - rt.lastActionAt > actionInterval + Random.nextLong(0, 2200)) {
                randomAction(rt, slot)
                rt.lastActionAt = now
            }
            if (config.speechEnabled && now - rt.lastSpeechAt > rt.nextSpeechDelay && !isQuietHour()) {
                val line = DialogueEngine.create(PetEvent.PERIODIC, slot, contextFor())
                speak(rt, line)
                rt.lastSpeechAt = now
                rt.nextSpeechDelay = speechDelay()
            }
        }

        if (tickCount % 1200L == 0L) updateNeeds() // approximately once a minute
        if (config.multiPetTalk && runtimes.size > 1 && tickCount % 4200L == 0L && Random.nextInt(100) < 40) {
            val rt = runtimes.random()
            speak(rt, DialogueEngine.create(PetEvent.MULTI_PET, config.slots[rt.slotIndex], contextFor()))
        }
    }

    private fun randomAction(rt: Runtime, slot: PetSlot) {
        val roll = Random.nextInt(100)
        when {
            slot.energy < 20 || roll < 18 -> rt.view.action("sleep", 4, 2400L)
            roll < 42 -> rt.view.action("happy", 1, 900L)
            roll < 58 -> rt.view.action("jump", 6, 950L)
            roll < 70 -> rt.view.action("idle", 2, 520L)
            roll < 82 -> rt.velocityX *= -1f
            else -> rt.view.action("idle", 11, 1300L)
        }
    }

    private fun updateNeeds() {
        if (!config.needsEnabled) return
        config.slots.take(config.activeCount).forEach { slot ->
            slot.hunger = (slot.hunger + 1).coerceAtMost(100)
            slot.energy = (slot.energy - if (slot.autoWalk) 1 else 0).coerceAtLeast(0)
            slot.cleanliness = (slot.cleanliness - Random.nextInt(0, 2)).coerceAtLeast(0)
            slot.mood = (slot.mood + when {
                slot.hunger > 85 -> -2
                slot.energy < 15 -> -2
                else -> 1
            }).coerceIn(0, 100)
        }
        PetPrefs.save(this, config)
    }

    override fun onMove(slotIndex: Int, dx: Int, dy: Int, finished: Boolean) {
        val rt = runtimes.firstOrNull { it.slotIndex == slotIndex } ?: return
        val slot = config.slots[slotIndex]
        rt.params.x += dx
        rt.params.y += dy
        runCatching { wm.updateViewLayout(rt.view, rt.params) }
        if (!finished && !rt.dragSpoken && abs(dx) + abs(dy) > 2) {
            rt.dragSpoken = true
            if (Random.nextInt(100) < 35) speak(rt, DialogueEngine.create(PetEvent.DRAG, slot, contextFor()))
        }
        if (finished) {
            slot.x = rt.params.x; slot.y = rt.params.y
            rt.dragSpoken = false
            PetPrefs.save(this, config)
            JournalStore.append(this, slot.name, "被你搬到了新的位置。")
        }
    }

    override fun onTap(slotIndex: Int) {
        val rt = runtimes.firstOrNull { it.slotIndex == slotIndex } ?: return
        val slot = config.slots[slotIndex]
        slot.affection += 1
        slot.mood = (slot.mood + 2).coerceAtMost(100)
        rt.view.action("happy", 1, 850L)
        speak(rt, DialogueEngine.create(PetEvent.TAP, slot, contextFor()))
        JournalStore.append(this, slot.name, "你轻轻点了它一下，它心情变好了。")
        PetPrefs.save(this, config)
    }

    override fun onDoubleTap(slotIndex: Int) {
        val rt = runtimes.firstOrNull { it.slotIndex == slotIndex } ?: return
        val slot = config.slots[slotIndex]
        slot.affection += 3
        slot.mood = (slot.mood + 5).coerceAtMost(100)
        rt.view.action("jump", 7, 1200L)
        speak(rt, DialogueEngine.create(PetEvent.DOUBLE_TAP, slot, contextFor()))
        JournalStore.append(this, slot.name, "收到了你的双击爱心。")
        PetPrefs.save(this, config)
    }

    override fun onLongPress(slotIndex: Int) {
        val rt = runtimes.firstOrNull { it.slotIndex == slotIndex } ?: return
        val slot = config.slots[slotIndex]
        speak(rt, DialogueEngine.create(PetEvent.LONG_PRESS, slot, contextFor()))
        config.selectedSlot = slotIndex
        PetPrefs.save(this, config)
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(intent)
    }

    private fun speakRandom(event: PetEvent) {
        val rt = runtimes.randomOrNull() ?: return
        speak(rt, DialogueEngine.create(event, config.slots[rt.slotIndex], contextFor()))
    }

    private fun speak(rt: Runtime, text: String) {
        if (!config.speechEnabled || text.isBlank()) return
        rt.view.showBubble(text, if (config.speechLevel >= 4) 3900L else 5000L, true)
        if (config.ttsEnabled && ttsReady && !isQuietHour()) {
            tts?.setSpeechRate(config.ttsRate / 100f)
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "qi_pet_${rt.slotIndex}_${System.currentTimeMillis()}")
        }
        if (config.journalEnabled && Random.nextInt(100) < 14) JournalStore.append(this, config.slots[rt.slotIndex].name, text)
    }

    private fun contextFor(): DialogueContext = DialogueContext(
        battery = battery,
        charging = charging,
        companionDays = ((System.currentTimeMillis() - getFirstRun()) / 86_400_000L).toInt().coerceAtLeast(1),
        ownerName = config.ownerName
    )

    private fun getFirstRun(): Long {
        val p = getSharedPreferences("qi_pet_meta", MODE_PRIVATE)
        val old = p.getLong("first_run", 0L)
        if (old > 0) return old
        val now = System.currentTimeMillis(); p.edit().putLong("first_run", now).apply(); return now
    }

    private fun speechDelay(): Long {
        val range = when (config.speechLevel.coerceIn(0, 4)) {
            0 -> 8 * 60_000L..15 * 60_000L
            1 -> 150_000L..260_000L
            2 -> 75_000L..145_000L
            3 -> 38_000L..75_000L
            else -> 20_000L..45_000L
        }
        return Random.nextLong(range.first, range.last + 1)
    }

    private fun isQuietHour(): Boolean {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return if (config.quietStart <= config.quietEnd) h in config.quietStart until config.quietEnd
        else h >= config.quietStart || h < config.quietEnd
    }

    private fun registerSystemReceiver() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(systemReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(systemReceiver, filter)
        }
    }

    private fun unregisterReceiverSafe() { runCatching { unregisterReceiver(systemReceiver) } }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW).apply {
                description = "让桌面宠物持续显示并保持互动"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stopIntent = PendingIntent.getService(this, 1, Intent(this, OverlayPetService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)
        return builder
            .setSmallIcon(R.drawable.app_icon)
            .setContentTitle("Qi桌面宠物正在陪伴你")
            .setContentText("点击进入编辑器；长按宠物也可以打开设置")
            .setContentIntent(openIntent)
            .addAction(Notification.Action.Builder(null, "关闭宠物", stopIntent).build())
            .setOngoing(true)
            .build()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + .5f).toInt()
}
