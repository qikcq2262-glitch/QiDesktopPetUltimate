# Qi Desktop Pet Ultimate keeps reflection-free model code, so no custom rules are required.
